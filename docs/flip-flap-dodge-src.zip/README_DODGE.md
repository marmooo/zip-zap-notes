# Flip Flap Dodge

Flip Flap Notes の `src/` を土台にした避けゲー版です。

## 導入

`flip-flap-notes` リポジトリのコピーに、この zip の `src/` を上書きしてください。
上書きするのは次の 7 ファイルだけで、音声解析・背景・favicon などはそのまま使います。

- `src/rhythm-game.js`（エンジン。判定を「タップ」から「衝突」に置き換え）
- `src/rhythm-game-worker.js`
- `src/index.js`
- `src/index.html` / `src/en/index.html` / `src/ja/index.html` / `src/zh/index.html`

その後は今までどおり `./server.sh` で動きます。パスは `/flip-flap-notes/` のままです。
設定の保存先は Flip Flap Notes と混ざらないよう `FlipFlapDodgeConfig` にしてあります。

## 遊び方

- 操作: 画面の左半分 / 右半分をタップ、または ← → / A D / F J で 1 レーンずつ移動
- ブロックと同じレーンにいる間は HP が減り、画面が赤くなります。HP 0 で死亡（GAME OVER）
- 譜面を最後まで生き延びるとクリア。スコアは「一度も当たらずに避けたブロックの割合」× 1,000,000

## 調整できる場所

- `RhythmGame` のオプション `maxHp`（既定 100）/ `damagePerSecond`（既定 50）
- `DIFFICULTIES` の `targetNps` / `maxSimultaneous` / `moveInterval`
- `BLOCK_MIN_DURATION` / `BLOCK_MAX_DURATION`（ブロックの最短・最長の長さ）
