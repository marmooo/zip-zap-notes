/**
 * index.js — Rhythm Game application entry point (MIDI / 音声 両対応統合版)
 *
 * MIDI モード: Midy を直接操作してMIDI/SoundFontを再生し、extractNotesFromMidy() でノート抽出。
 * 音声モード: ネイティブ <audio> で音声ファイルを再生し、audio-beatmap.js + beatmap-worker.js で
 *            オンセット検出→テンポ推定→ビートトラッキング→拍グリッド吸着 により譜面を自動生成。
 *
 * どちらのモードも最終的には同じ形のノート配列 { noteNumber, startTime, endTime, channel,
 * programNumber } を rawNotes に格納し、そこから先（thinNotes によるレーン配置・
 * rhythm-game-worker.js での判定/描画）は完全に共通。
 */

import { Midy } from "https://cdn.jsdelivr.net/gh/marmooo/midy@0.6.7/dist/midy.min.js";
import { Modal } from "https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/+esm";
import {
  DIFFICULTIES,
  extractNotesFromMidy,
  thinNotes,
} from "./rhythm-game.js";
import { MidiLibrary } from "https://marmooo.github.io/free-midi/midi-library.js";
import { installIOSTouchGuards } from "/flip-flap-notes/ios-touch-guards.js";

// ---------------------------------------------------------------------------
// 定数
// ---------------------------------------------------------------------------

// MIDI / 音声 共通の開始遅延。ノートが判定ラインに到達する前にスクロールインする
// リードイン時間。midy.startDelay にも同じ値を渡す。
const START_DELAY = 3; // 秒

// rhythm-game.js のレーン描画は perspective 分だけ台形状に収束する。
// pointerdown の座標→レーン変換もこれに合わせて逆変換する（#perspX の逆変換）。
const PERSPECTIVE = 0.78; // rhythm-game.js のコンストラクタ既定値と合わせる

const ANALYZE_TIMEOUT_MS = 30000;

// SHORT: 一般的な音ゲー尺（120秒）で強制終了。ORIGINAL: 曲の最後まで。
const SHORT_DURATION = 120; // 秒
const ENDING_FADE_DURATION = 2; // 秒。SHORT到達時のフェードアウト長

// btnPause の一時停止/再開アイコン。絵文字（⏸/▶）はフォント・OSによって
// サイズや縦位置が揺れて丸ボタンからはみ出す/欠けることがあるため、
// 固定サイズの SVG に置き換えている。
const ICON_PAUSE =
  '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" ' +
  'viewBox="0 -960 960 960" fill="currentColor" aria-hidden="true">' +
  '<path d="M555-200v-560h175v560H555Zm-325 0v-560h175v560H230Z"></path>' +
  "</svg>";
const ICON_PLAY =
  '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" ' +
  'viewBox="0 -960 960 960" fill="currentColor" aria-hidden="true">' +
  '<path d="M320-203v-560l440 280-440 280Z"></path>' +
  "</svg>";

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const isIOS = /iP(ad|hone|od)/.test(navigator.userAgent) ||
  (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
const DEFAULT_CONFIG = {
  laneCount: 4,
  scrollSpeed: 500,
  laneColors: [
    "#ff6666",
    "#66ccff",
    "#ffcc66",
    "#66ff99",
    "#cc66ff",
    "#ff9966",
    "#66ffcc",
    "#ff66cc",
  ],
  difficulty: "BASIC",
  laneOpacity: 0.35, // 0(透明)〜1(最大まで濃い) の通常の opacity と同じスケール
  perspectiveEnabled: true, // 遠近感（画面上側が狭くなる表示）のON/OFF
  judgeOffset: 0, // ms (正=遅く/音が遅い環境, 負=早く)
  accentColor: "", // "" = 未設定（currentColor に自動追従。テーマ切替でも見えなくならない）
  judgeLineColor: "", // "" = 未設定（uiColor / currentColor に自動追従）
  laneLineColor: "", // "" = 未設定（uiColor / currentColor に自動追従）
  backgroundPreset: "/flip-flap-notes/data/cyber-network.webp", // 初期値はCyber Network。""=なし / プリセットURL / "custom"（本体は IndexedDB に保存）
  // Canvas 解像度の上限（devicePixelRatio をこの値でキャップ）。
  // 既定 1 = 負荷を抑えて安定優先。高いほどシャープだがメモリ/GPU 負荷が増え、モバイルで不安定になりやすい。
  maxPixelRatio: 1,
  // Midy の sample キャッシュ粒度。none → ads → adsr → note → segment → chunk。
  // 高いほど複雑な MIDI で効率が良いが、iOS の OfflineAudioContext 不具合で落ちやすくなる。
  cacheMode: isIOS ? "none" : "chunk",
};

// midy.cacheMode の段階（スライダー 0–5 と対応）
const CACHE_MODES = ["none", "ads", "adsr", "note", "segment", "chunk"];

function cacheModeIndex(mode) {
  const i = CACHE_MODES.indexOf(mode);
  return i >= 0 ? i : CACHE_MODES.indexOf("chunk");
}

function cacheModeLabel(modeOrIndex) {
  const i = typeof modeOrIndex === "number"
    ? modeOrIndex
    : cacheModeIndex(modeOrIndex);
  const clamped = Math.min(CACHE_MODES.length - 1, Math.max(0, i));
  return `${clamped} (${CACHE_MODES[clamped]})`;
}

function loadConfig() {
  try {
    const loaded = {
      ...DEFAULT_CONFIG,
      ...JSON.parse(localStorage.getItem("FlipFlapDodgeConfig") || "{}"),
    };
    return loaded;
  } catch (err) {
    console.warn("Failed to load saved config, falling back to defaults:", err);
    return { ...DEFAULT_CONFIG };
  }
}
function saveConfig(c) {
  localStorage.setItem("FlipFlapDodgeConfig", JSON.stringify(c));
}
// "rgb(r, g, b)" 形式（getComputedStyle が返す形式）を <input type=color> 用の
// "#rrggbb" に変換する。パースできない場合は null を返す。
function rgbToHex(rgbStr) {
  const m = rgbStr?.match(/\d+/g);
  if (!m || m.length < 3) return null;
  return "#" + m.slice(0, 3).map((n) => Number(n).toString(16).padStart(2, "0"))
    .join("");
}
let config = loadConfig();
// 旧設定や不正値を既定範囲に丸める
{
  const v = Number(config.maxPixelRatio);
  config.maxPixelRatio = Number.isFinite(v) ? Math.min(3, Math.max(1, v)) : 1;
  if (!CACHE_MODES.includes(config.cacheMode)) {
    config.cacheMode = DEFAULT_CONFIG.cacheMode;
  }
}

// ---------------------------------------------------------------------------
// DOM refs
// ---------------------------------------------------------------------------

// HTML側の #i18nStrings [data-key] からテキストを取得する（多言語化しやすくするため、
// alert/エラーメッセージ等 JS 側でしか組み立てられない文言もここ経由でHTMLから引く）。
// vars を渡すと文字列中の {key} をプレースホルダ置換する（例: t("analyzeTimeout", { seconds: 30 })）。
function t(key, vars) {
  const el = document.querySelector(`#i18nStrings [data-key="${key}"]`);
  let text = el ? el.textContent : key;
  if (vars) {
    for (const [k, v] of Object.entries(vars)) text = text.replace(`{${k}}`, v);
  }
  return text;
}

const canvasWrap = document.getElementById("canvasWrap");
let noteCanvas = document.getElementById("noteCanvas");
let particleCanvas = document.getElementById("particleCanvas");
let uiCanvas = document.getElementById("uiCanvas");
const screenStart = document.getElementById("screenStart");
const screenReady = document.getElementById("screenReady");
const screenAnalyzing = document.getElementById("screenAnalyzing");
const screenResult = document.getElementById("screenResult");
const screenSettings = document.getElementById("screenSettings");
const pauseOverlay = document.getElementById("pauseOverlay");
const btnPause = document.getElementById("btnPause");
const scoreDisplay = document.getElementById("scoreDisplay");
const player = document.getElementById("player"); // 音声モード用 <audio>

// btnPause と scoreDisplay は常に同じタイミングで表示/非表示になる
// （#hudStack 内で並んで表示される一組の HUD のため）ので、まとめて操作する。
// scoreDisplay は「HTML が古いまま（キャッシュ等）で #hudStack 側の変更が
// 反映されていない」場合に null になり得るため、その場合も他のUIが落ちない
// よう optional chaining で防御する。
function showPlayHud() {
  pauseOverlay.classList.add("hidden");
  btnPause.classList.remove("hidden");
  btnPause.innerHTML = ICON_PAUSE;
  scoreDisplay?.classList.remove("hidden");
  if (scoreDisplay) scoreDisplay.textContent = "0000000";
}
function hidePlayHud() {
  pauseOverlay.classList.add("hidden");
  btnPause.classList.add("hidden");
  scoreDisplay?.classList.add("hidden");
}

// MIDI / SoundFont ライブラリ、設定画面はすべて Bootstrap の modal で表示する
const libraryModal = Modal.getOrCreateInstance(
  document.getElementById("screenLibrary"),
);
const soundFontModal = Modal.getOrCreateInstance(
  document.getElementById("soundFontLibraryModal"),
);
const settingsModal = Modal.getOrCreateInstance(screenSettings);
// 結果画面はスコア確定後の一時停止的な画面のため、背景クリックや Esc で
// 誤って閉じてしまわないよう backdrop: "static" / keyboard: false にする
// （閉じるには Play again / Random MIDI / Back to start screen のいずれかを押す）。
const resultModal = Modal.getOrCreateInstance(screenResult, {
  backdrop: "static",
  keyboard: false,
});
const htmlLang = document.documentElement.lang || "en";

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

// Canvas の実効 DPR。devicePixelRatio を config.maxPixelRatio でキャップする。
// 既定は 2（Retina 相当）で、高 DPI 端末でのメモリ/GPU 負荷を抑えて落ちにくくする。
// 設定画面から変更可能。変更時は Worker / OffscreenCanvas を再構築する。
function computeDpr() {
  const device = globalThis.devicePixelRatio || 1;
  const cap = Number(config.maxPixelRatio);
  if (!Number.isFinite(cap) || cap <= 0) return device;
  return Math.min(device, cap);
}
let dpr = computeDpr();
let mode = null; // null | "midi" | "audio" — 最初のファイル読込までは未確定
let rawNotes = []; // NoteData[]（midy由来 or 音声解析由来。形は共通）
let laneNotes = []; // thinNotes済み
let worker = null;
let beatWorker = null; // 音声モードの解析ワーカー（コーディネーター）
let rafId = null;
let tickIntervalId = null; // バックグラウンドでも tick / 終了判定を回すための interval
let gamePhase = "start"; // start | ready | analyzing | playing | result
let isPaused = false; // gamePhase==="playing" 中の一時停止フラグ

let playLength = "short"; // "short" | "original"
let maxDuration = Infinity; // applyNotes() 実行時に playLength から算出される、現在有効な上限秒数
let endingFadeStarted = false; // SHORTモードでの強制終了フェードを開始済みか
let endingFadeStartPerf = 0; // フェード開始時点の performance.now()（下記参照）
let endingFadeTimeoutId = null; // rAF停止時でもフェード完了→showResultを保証するタイマー

// applyNotes の再計算・Worker への再送を抑えるキー。リプレイ時に同じ譜面を
// 何度も thinNotes + structured clone するとピークメモリが跳ねるため、
// 設定・譜面が変わっていないときは再計算/再送をスキップする。
let lastApplyKey = "";
let notesPostedToWorker = false; // 現在の Worker に laneNotes が載っているか

let notesReady = false; // 音声モード: 現在の設定で譜面生成済みか
let notesStale = true; // 音声モード: 設定変更等で再生成が必要か
let isAnalyzing = false; // 音声モード: 解析中の多重起動防止（gamePhaseとは別管理）
let suppressPauseHandling = false; // 音声モード: 自前pause()をuser-pauseと誤認しないためのフラグ
// MIDI: ユーザーがトグルした一時停止だけ paused ハンドラで UI/rAF を止める。
// SHORT終了・stopAllPlayback のシステム pause は立てない。
let userInitiatedMidiPause = false;
// completeShortEnding() / ORIGINAL自然終了時の systemPauseMidi() が進行中なら、
// その Promise を保持する。startMidiPlayback() はこれを待ってから
// midy.isPaused を見ることで、「pause() 完了前に isPaused=false を見て
// 誤って stop+start フォールバックに落ちる」競合を無くす。
let systemPausePromise = null;

// 音声モードの開始遅延（START_DELAY）。MIDI の midy.startDelay に相当。
// リードイン中は <audio> をまだ再生せず、壁時計でゲーム時刻を -START_DELAY → 0 まで進める。
// 0 到達時に player.play() してノート時刻と音を同期する。
let _audioLeadIn = false;
let _audioLeadInStartPerf = 0;
let _audioLeadInTimeoutId = null;

// 1 プレイ分の結果。Worker の judgment / judgmentDetail メッセージで更新される。
function emptyResult(total) {
  return {
    score: 0,
    combo: 0, // 最大連続回避数
    dodge: 0,
    hit: 0,
    hp: 100,
    maxHp: 100,
    progress: 0,
    dead: false,
    total,
  };
}
let lastResult = emptyResult(0);
let pendingAnalysisResolve = null;
let pendingAnalysisReject = null;

// ---------------------------------------------------------------------------
// Canvas sizing
// ---------------------------------------------------------------------------

function setWrapHeight() {
  // #topnav は position:fixed で canvas の上に透過オーバーレイとして
  // 浮かせているだけでレイアウト上の高さを消費しないため、canvasWrap の
  // 高さからは差し引かない（iPhone SE の横置きのような縦が狭い端末でも
  // canvas を画面いっぱいに使えるようにするため）。
  // ただし #topnav のブランドロゴ／ボタンは canvas と同じ左上・右上の
  // コーナーに重なって浮いているため、#hudStack（pause/attribution/score）は
  // この高さぶんだけ避けてやる必要がある。その受け渡し用に --topbar-h を
  // CSS 変数として置いておく（#hudStack 自身の縦積み/横並びの切り替えは
  // CSS Grid のメディアクエリ側で完結しており、ここでは関与しない）。
  const topbarH = document.getElementById("topnav")?.offsetHeight ?? 0;
  document.documentElement.style.setProperty("--topbar-h", topbarH + "px");

  // 将来 footer を追加する場合に備え、#pagefooter があれば高さを差し引く対象に含める
  // （中身が空 / hidden の間は offsetHeight が 0 になるだけなので、今は何もしなくてよい）
  const footerH = document.getElementById("pagefooter")?.offsetHeight ?? 0;

  // ファイル選択パネルは screenStart のオーバーレイ内にあり、canvasWrap 自体の
  // レイアウト（高さ）には影響しない。gamePhase によってサイズを変えると
  // 画面遷移のたびにガクッとリサイズされて見た目が悪いので、常に
  // 「プレイ中と同じ画面いっぱいのサイズ」（フッター分だけ差し引く）に固定する。
  canvasWrap.style.height = Math.max(300, globalThis.innerHeight - footerH) +
    "px";
  resizeCanvases();
}
globalThis.addEventListener("resize", setWrapHeight);

function resizeCanvases() {
  const r = canvasWrap.getBoundingClientRect();
  const w = Math.round(r.width * dpr);
  const h = Math.round(r.height * dpr);
  // rhythm-game-worker.js 側でスコア等の右上 HUD を描く際、canvas 座標系
  // （dpr 込み）でどれだけ避ければ #topnav と重ならないかを渡す。
  // buttonZoneHeight / dpr も一緒に送り、向き変更時も見た目比率を保つ。
  if (worker) {
    worker.postMessage({
      type: "resize",
      width: w,
      height: h,
      topInset: computeTopInset(),
      buttonZoneHeight: Math.round(h * 0.2),
      dpr,
    });
  }
  try {
    noteCanvas.width = w;
    noteCanvas.height = h;
    particleCanvas.width = w;
    particleCanvas.height = h;
    uiCanvas.width = w;
    uiCanvas.height = h;
  } catch {
    /* skip: transferControlToOffscreen 済みのcanvasはメインスレッドから幅高さを変更できない */
  }
  return [w, h];
}

// ---------------------------------------------------------------------------
// currentGameTime: モードによって時間の基準が異なる
// ---------------------------------------------------------------------------

// midy.currentTime() は resume 直後に startTime が確定するまで不安定になることがあり、
// これが原因で resume 後しばらく判定（PERFECT/MISS等）がおかしくなる不具合があった。
// → resume直後は「resume時点のゲーム内時刻 + 経過した壁時計時間」で近似した値を使い、
//   実測値（midy.currentTime()）がその近似値に実際に収束するまで待ってから切り替える。
//   固定時間待つだけだと、内部の startTime 確定が重い曲/遅い端末などでその時間を
//   超えた場合に「まだ不安定な実測値」へ早く切り替わってしまい、ノーツが一瞬
//   ジャンプ/消えたように見えることがあったため、実測値どうしを比較して収束を
//   確認する方式にしてある（安全弁として最大待ち時間も設けておく）。
let _pausedAt = 0;
let _resumeBaseGameTime = 0;
let _resumeBasePerf = 0;
let _resumeStabilizeMinUntil = 0; // performance.now() 基準：最低でもここまでは近似値を使う
let _resumeStabilizeMaxUntil = 0; // performance.now() 基準：ここを過ぎたら実測値が
// 収束していなくても強制的に切り替える（安全弁）
const RESUME_STABILIZE_MIN_MS = 50;
const RESUME_STABILIZE_MAX_MS = 500;
const RESUME_STABILIZE_TOLERANCE_SEC = 0.05; // 実測値と近似値の許容差（50ms）

function currentGameTime() {
  if (mode === "midi") {
    const now = performance.now();
    const approx = _resumeBaseGameTime + (now - _resumeBasePerf) / 1000;
    if (isPaused) return _pausedAt;
    if (now < _resumeStabilizeMinUntil) {
      return approx;
    }
    // UI 再生中だが midy がまだ pause のときだけ壁時計（startDelay 中は isPaused=false かつ midy 再生中）
    if (midy.isPaused && _resumeBasePerf > 0) {
      return approx;
    }
    const real = midy.currentTime() - START_DELAY;
    if (
      now < _resumeStabilizeMaxUntil &&
      Math.abs(real - approx) > RESUME_STABILIZE_TOLERANCE_SEC
    ) {
      return approx;
    }
    return real;
  }
  if (_audioLeadIn) {
    if (isPaused) return _pausedAt;
    return (performance.now() - _audioLeadInStartPerf) / 1000 - START_DELAY;
  }
  return player.currentTime;
}

// ---------------------------------------------------------------------------
// Worker 管理（rhythm-game-worker.js をそのまま使用。MIDI/音声共通）
// ---------------------------------------------------------------------------

// #topnav は canvas の上に浮く透過オーバーレイのため、rhythm-game-worker.js
// 側で canvas 中央の combo 表示を描くときに、#hudStack（pause/attribution/
// score。score は現在 DOM 表示なので実体は pause+attribution）の高さぶんだけ
// 避けないと重なってしまう。#hudStack は幅広画面では横並び1行、狭い/低い
// 画面では attribution が上に乗って2行になる（CSS Grid のメディアクエリで
// 自動切り替え）ため、実際のレイアウト後の高さを直接測る。
// canvas は dpr 込みの座標系なので dpr を掛けて渡す。
function computeTopInset() {
  const topbarH = document.getElementById("topnav")?.offsetHeight ?? 0;
  const hudStackH = document.getElementById("hudStack")?.offsetHeight ?? 0;
  return Math.round((topbarH + hudStackH) * dpr);
}

function buildWorkerOptions() {
  const laneCount = config.laneCount;
  const h = Math.round(canvasWrap.getBoundingClientRect().height * dpr);
  return {
    laneCount,
    // scrollSpeed / noteHeight は論理px（dpr=1基準）。Worker 側で dpr を掛けて描画する。
    scrollSpeed: config.scrollSpeed,
    dpr,
    laneColors: config.laneColors.slice(0, laneCount),
    difficulty: DIFFICULTIES[config.difficulty] ?? DIFFICULTIES.NORMAL,
    judgeOffset: (config.judgeOffset ?? 0) / 1000,
    startDelay: START_DELAY,
    laneOpacity: config.laneOpacity ?? 0.35,
    buttonZoneHeight: Math.round(h * 0.2),
    perspective: (config.perspectiveEnabled ?? true) ? PERSPECTIVE : 0,
    uiColor: computeUiColor(),
    judgeLineColor: config.judgeLineColor || "",
    laneLineColor: config.laneLineColor || "",
    accentColor: config.accentColor || "",
    // canvas 座標系（dpr込み）での navbar 回避量。HUD 描画開始 y に加算する。
    topInset: computeTopInset(),
  };
}

// rhythm-game.js（Worker内で実行される）は Canvas なので CSS の currentColor を
// 直接参照できない。そのためメインスレッド側で「今の文字色」を計算して渡す。
// data-bs-theme を切り替えても常に見えるレーン区切り線・判定ライン・キーラベル・
// HUD文字の土台色として使われる。
function computeUiColor() {
  return getComputedStyle(document.body).color || "#ffffff";
}

// #scoreDisplay（DOM）を Canvas HUD と同じ色ロジックで塗るための橋渡し。
// rhythm-game.js の drawHUD が使う「accentColor || uiColor」の優先順位に合わせる。
function syncScoreColor() {
  document.documentElement.style.setProperty(
    "--score-color",
    config.accentColor || computeUiColor(),
  );
}

function initWorker() {
  if (worker) {
    try {
      worker.terminate();
    } catch {
      /* ignore */
    }
    worker = null;
  }
  notesPostedToWorker = false;
  replaceCanvases();

  worker = new Worker("/flip-flap-notes/rhythm-game-worker.js", {
    type: "module",
  });
  worker.onmessage = onWorkerMessage;
  // Worker が落ちた場合は参照を捨て、次回 ensureWorker / startGameMidi で
  // 再構築できるようにする（null のまま残すとリプレイが永久に動かなくなる）。
  worker.onerror = (err) => {
    console.error("rhythm-game-worker crashed:", err);
    try {
      worker?.terminate();
    } catch {
      /* ignore */
    }
    worker = null;
    notesPostedToWorker = false;
  };

  const r = canvasWrap.getBoundingClientRect();
  const w = Math.round(r.width * dpr);
  const h = Math.round(r.height * dpr);
  noteCanvas.width = w;
  noteCanvas.height = h;
  particleCanvas.width = w;
  particleCanvas.height = h;
  uiCanvas.width = w;
  uiCanvas.height = h;

  const noteOff = noteCanvas.transferControlToOffscreen();
  const particleOff = particleCanvas.transferControlToOffscreen();
  const uiOff = uiCanvas.transferControlToOffscreen();

  syncScoreColor(); // Canvas HUD（accentColor||uiColor）と #scoreDisplay の色を揃える
  worker.postMessage(
    {
      type: "init",
      noteCanvas: noteOff,
      particleCanvas: particleOff,
      uiCanvas: uiOff,
      options: buildWorkerOptions(),
    },
    [noteOff, particleOff, uiOff],
  );
}

function replaceCanvases() {
  for (const id of ["noteCanvas", "particleCanvas", "uiCanvas"]) {
    const old = document.getElementById(id);
    const neo = document.createElement("canvas");
    neo.id = id;
    neo.className = old.className;
    old.replaceWith(neo);
    if (id === "noteCanvas") noteCanvas = neo;
    if (id === "particleCanvas") particleCanvas = neo;
    if (id === "uiCanvas") {
      uiCanvas = neo;
      uiCanvas.tabIndex = -1; // フォーカス可能に（キーボード操作を確実に拾うため）
      // pointer-events / outline は #uiCanvas に対する CSS 側で指定済み
      bindPointerEvents(neo);
    }
  }
}

// 死亡演出中に音楽を素早くフェードアウトする。実際の pause は結果画面遷移時
// （gameOver メッセージ）に行う。音量は次回再生の開始時に復元される
// （MIDI: startMidiPlayback、音声: beginPlayback）。
const DEATH_FADE_SEC = 0.6;
// 死亡から結果画面までの上限。Worker の演出（約 1.2 秒）より少し長くとる。
const DEATH_RESULT_MS = 1600;
let deathTimeoutId = null;

// 死亡演出を終えて結果画面へ。Worker の gameOver とタイマーのどちらが先でも 1 回だけ実行される。
function finishDeath() {
  clearTimeout(deathTimeoutId);
  deathTimeoutId = null;
  if (gamePhase !== "playing") return;
  stopRaf();
  showResult();
  if (mode === "midi") {
    systemPauseMidi();
  } else {
    suppressPauseHandling = true;
    try {
      player.pause();
    } catch {
      /* ignore */
    }
  }
}
function fadeOutMusicForDeath() {
  if (mode === "midi") {
    midy.fadeOutMasterVolume(DEATH_FADE_SEC);
    return;
  }
  const startVolume = player.volume;
  const startPerf = performance.now();
  const step = () => {
    if (gamePhase !== "playing") return; // 結果画面に移った/リプレイされた
    const k = Math.min(1, (performance.now() - startPerf) / (DEATH_FADE_SEC * 1000));
    player.volume = startVolume * (1 - k);
    if (k < 1) setTimeout(step, 30);
  };
  step();
}

function onWorkerMessage(e) {
  const msg = e.data;
  switch (msg.type) {
    case "judgment":
      lastResult.score = msg.score;
      lastResult.combo = Math.max(lastResult.combo, msg.combo);
      break;
    case "dying":
      // HP が 0 になった瞬間。死亡演出（爆発）を見せる間は音楽を先に落とす。
      // 結果画面へは Worker が演出後に送る "gameOver" で遷移する。
      // tick が途中で止まっても（SHORT 終了・曲の自然終了・一時停止と重なった場合）
      // 結果画面に必ず行けるよう、タイマーでも同じ遷移を予約しておく。
      if (gamePhase !== "playing") break;
      fadeOutMusicForDeath();
      clearTimeout(deathTimeoutId);
      deathTimeoutId = setTimeout(finishDeath, DEATH_RESULT_MS);
      break;
    case "gameOver":
      finishDeath();
      break;
    case "judgmentDetail":
      lastResult = { ...lastResult, ...msg };
      break;
    case "noteCount":
      document.getElementById("noteCountLabel").textContent = msg.count;
      document.getElementById("diffLabel").textContent = config.difficulty;
      lastResult.total = msg.count;
      break;
    case "ended": {
      // maxDuration === Infinity（ORIGINAL、または実尺 ≤ SHORT の SHORT）:
      //   ノート消化＝自然終了 → スコア画面。MIDI は systemPause で paused に
      //   収束させ、リプレイは seekTo(0)+resume() で再開できる。
      // maxDuration 有限（実尺 > SHORT の SHORT）:
      //   120s 強制終了用のフェードへ。ノート消化が先に来た場合も同様。
      // finalize 付き stop（曲終了・SHORTフェード完了）からもここに来る。
      // その場合は endingFadeStarted や maxDuration 到達済みなので即 showResult。
      if (gamePhase !== "playing") break;
      // ユーザー一時停止中の tick / midy.pause 由来の誤 ended でスコア画面に行かない
      if (isPaused || userInitiatedMidiPause) break;
      if (maxDuration === Infinity || endingFadeStarted) {
        stopRaf();
        showResult();
        if (mode === "midi") systemPauseMidi();
      } else if (currentGameTime() >= maxDuration - 0.1) {
        maxDuration = Math.min(maxDuration, currentGameTime());
        handleShortEnding(currentGameTime());
      } else {
        // ノートは尽きたがまだ maxDuration 前 → 残りは無音で時刻だけ進む。
        // handleShortEnding は gameLogicTick 側の maxDuration 到達で発火する。
      }
      break;
    }
  }
}

// ---------------------------------------------------------------------------
// thinNotes をメインスレッドで実行して Worker に渡す（MIDI/音声共通）
// ---------------------------------------------------------------------------

// MIDIモードでの曲の実尺（＝最後のノートの終了時刻）を返す。
// rawNotes は startTime/endTime とも currentGameTime() と同じ時間軸（startDelay
// を含まない）なので、maxDuration の算出やSHORT/ORIGINAL表示にそのまま使える。
function getMidiSongDuration() {
  let max = 0;
  for (const n of rawNotes) {
    if (n.endTime > max) max = n.endTime;
  }
  return max;
}

// SHORT/ORIGINAL表示、および音声モードでの曲の実尺算出に使う。
// MIDIモードは rawNotes 由来（getMidiSongDuration）、音声モードは
// decodeAudioData 済みの audioBuffer.duration をそのまま使う。
function getSongDuration() {
  if (mode === "midi") return getMidiSongDuration();
  return audioBuffer ? audioBuffer.duration : 0;
}

function applyNotes(forceResend = false) {
  if (!worker || rawNotes.length === 0) return;
  // SHORT は「長い曲を SHORT_DURATION で切る」ためのモード。
  // 曲の実尺が SHORT_DURATION 以下なら SHORT と ORIGINAL は同じ尺なので、
  // 強制フェード（handleShortEnding）は使わず自然終了させる。
  // （実尺付近で fade + systemPause と midy の自然 stopped が重なると、
  //  リプレイ時に isPaused まわりが不安定になるため）
  if (playLength === "short") {
    const songDuration = getSongDuration();
    if (songDuration > 0 && songDuration <= SHORT_DURATION) {
      maxDuration = Infinity;
    } else {
      // 実尺不明 or SHORT より長い → 120 秒で切る
      maxDuration = SHORT_DURATION;
    }
  } else {
    maxDuration = Infinity;
  }

  // 同じ譜面・同じ設定なら thinNotes の再計算を省略する。
  // リプレイ時に毎回フル配列を structured clone するとピークメモリが跳ねるので、
  // Worker に既に載っている場合は postMessage 自体もスキップする。
  const applyKey = [
    playLength,
    maxDuration,
    config.laneCount,
    config.difficulty,
    rawNotes.length,
  ].join("|");
  if (applyKey === lastApplyKey && laneNotes.length > 0) {
    if (forceResend || !notesPostedToWorker) {
      worker.postMessage({ type: "setNotes", notes: laneNotes });
      notesPostedToWorker = true;
    }
    return;
  }

  const diff = DIFFICULTIES[config.difficulty] ?? DIFFICULTIES.NORMAL;
  // sort は破壊的なのでコピーしてから並べる（rawNotes の順序を壊さない）
  const notes = rawNotes
    .filter((n) => n.startTime < maxDuration)
    .sort((a, b) => a.startTime - b.startTime);
  laneNotes = thinNotes(notes, config.laneCount, diff);
  lastApplyKey = applyKey;
  worker.postMessage({ type: "setNotes", notes: laneNotes });
  notesPostedToWorker = true;
}

// ---------------------------------------------------------------------------
// rAF ループ
// ---------------------------------------------------------------------------

// メインスレッドから Worker へ現在時刻を送り、SHORT終了判定も行う。
// rAF（描画用）と setInterval（バックグラウンド耐性）の両方から呼ばれる。
function gameLogicTick() {
  if (gamePhase !== "playing" || isPaused || userInitiatedMidiPause) return;
  const t = currentGameTime();
  try {
    worker?.postMessage({ type: "tick", currentTime: t });
  } catch (err) {
    console.error("tick postMessage failed:", err);
  }
  if (maxDuration !== Infinity) handleShortEnding(t);
}

function startRaf() {
  if (rafId !== null) return;
  function loop() {
    gameLogicTick();
    // スコアは "judgment" メッセージで lastResult.score に随時反映されるが、
    // DOM 表示（#scoreDisplay）への書き戻しは毎フレームここでまとめて行う
    // （以前は Canvas 側で毎フレーム再描画していたのと同じ頻度・同じ場所）。
    if (scoreDisplay) {
      scoreDisplay.textContent = String(Math.round(Number(lastResult.score) || 0))
        .padStart(7, "0");
    }
    // handleShortEnding() が showResult()→stopRaf() を呼んで rafId を null に
    // していたら、ここで再度スケジュールしてしまわないようにする。
    if (rafId !== null) rafId = requestAnimationFrame(loop);
  }
  rafId = requestAnimationFrame(loop);

  // タブがバックグラウンドだと rAF が停止／大幅間引きされる。
  // Worker のノート進行・ended 判定、SHORT の maxDuration 到達判定が止まるため、
  // setInterval でも同じロジックを回す（裏で音楽が鳴っていても終了→スコア画面へ）。
  if (tickIntervalId === null) {
    tickIntervalId = setInterval(gameLogicTick, 250);
  }
}
function stopRaf() {
  if (rafId !== null) {
    cancelAnimationFrame(rafId);
    rafId = null;
  }
  if (tickIntervalId !== null) {
    clearInterval(tickIntervalId);
    tickIntervalId = null;
  }
}

// SHORTモード：maxDuration到達でフェードアウトしつつ一時停止する。
// stop() ではなく pause() を使うことでキャッシュを保持し、
// 再プレイ時は resume() で即座に再開できる（SoundFont の再読み込みも不要）。
// pause 後に seekTo(0) して位置を先頭に戻す処理は "paused" イベントハンドラで行う。
// gamePhase を先に "result" にしてから pause()/player.pause() を呼ぶことで、
// pause イベントハンドラが「ユーザーによる一時停止」と誤認しないようにする
// （既存の gamePhase==="playing" ガードにそのまま乗る）。
//
// 注意：フェード完了判定には壁時計（performance.now()）を使う。
// maxDuration を曲の実尺（rawNotes 由来）でキャップしている場合、
// フェード開始とほぼ同時に midy 自身が自然終了（isPlaying=false）してしまい、
// currentTime()（延いては t=currentGameTime()）がそこで止まってしまう
// （isPlaying=false の間 currentTime() は resumeTime を返し続け、進まなくなる）。
// t の進行に依存して "maxDuration + ENDING_FADE_DURATION" 判定をしていると、
// 曲が自然終了した瞬間に t の増加も止まり、いつまでも条件を満たせず
// showResult() が呼ばれない（＝スコア画面が出ない）不具合になるため。
//
// さらに、タブがバックグラウンドのときは requestAnimationFrame が停止するため、
// フェード開始時に setTimeout でも完了を予約し、音楽が裏で鳴り続けていても
// 確実にスコア画面へ遷移させる。
// gamePhase を "result" にした直後、mode==="midi" のときに呼ぶ。
// SHORT のフェード終了・ORIGINAL の自然終了（ノート消化）いずれの経路でも、
// midy を確実に paused 状態へ収束させる（seekTo(0) 等の後始末は既存の
// midy "paused" イベントリスナーが gamePhase==="result" を見て行う）。
// startMidiPlayback() 側は systemPausePromise を await することで、
// 「pause() が完了しきる前に isPaused=false を観測してしまう」競合
// （＝曲の実尺が SHORT_DURATION/ノート消化タイミングと際どく重なる曲で、
// リプレイ時にゲームが始まらない・スペースキーでようやく動く原因）を避ける。
// なお pause() は「システム pause」（userInitiatedMidiPause は立てない）。
//
// 曲の実尺が SHORT_DURATION 以下（maxDuration===Infinity）の場合、ここに来る
// 時点で midy は「フェードで強制中断された」のではなく、既に自然終了
// （stopped: isPlaying=false, isPaused=false）していることがある。
// この状態で pause() を呼ぶと、実際には再生も一時停止もしていないのに
// isPaused だけが中途半端に true になり得て、次のリプレイ時に
// startMidiPlayback() が「resume() で再開できる」と誤判定してしまう。
// resume() は実際に鳴らすべき音源が無いため resumed イベントが発火せず、
// gamePhase が "result" のまま固まって見える（＝pause画面は出ないのに
// 始まらない不具合の原因）。
// これを避けるため、midy がまだ実際に再生中のとき（＝SHORTのフェード
// カットで中断する通常ケース）だけ pause() する。既に自然終了している
// 場合は何もせず、次のリプレイは startMidiPlayback() 側の
// 「midiHasStartedOnce なら必ず stop()→start()」経路に確実に任せる。
function systemPauseMidi() {
  if (!midy.isPlaying) {
    systemPausePromise = null;
    return Promise.resolve();
  }
  const promise = midy.pause()
    .catch((err) => console.error("midy.pause failed:", err))
    .finally(() => {
      if (systemPausePromise === promise) systemPausePromise = null;
    });
  systemPausePromise = promise;
  return promise;
}

function completeShortEnding() {
  if (gamePhase !== "playing") return;
  if (endingFadeTimeoutId !== null) {
    clearTimeout(endingFadeTimeoutId);
    endingFadeTimeoutId = null;
  }
  stopRaf();
  // 未確定ホールドを確定してから judgmentDetail → ended → showResult へ
  let t = 0;
  try {
    t = currentGameTime();
  } catch {
    /* ignore */
  }
  try {
    worker?.postMessage({ type: "stop", currentTime: t, finalize: true });
  } catch (err) {
    console.error("worker stop failed:", err);
    showResult();
    if (mode === "midi") {
      systemPauseMidi();
    } else {
      suppressPauseHandling = true;
      player.pause();
    }
    return;
  }
  // MIDI/audio の停止は ended ハンドラ側（showResult 後）で行う
  if (mode === "audio") {
    suppressPauseHandling = true;
    try {
      player.pause();
    } catch {
      /* ignore */
    }
  }
}

function handleShortEnding(t) {
  if (t < maxDuration) return;
  if (!endingFadeStarted) {
    endingFadeStarted = true;
    endingFadeStartPerf = performance.now();
    if (mode === "midi") midy.fadeOutMasterVolume(ENDING_FADE_DURATION);
    // rAF が止まってもフェード完了→showResult を保証（+50ms の余裕）
    if (endingFadeTimeoutId !== null) clearTimeout(endingFadeTimeoutId);
    endingFadeTimeoutId = setTimeout(() => {
      endingFadeTimeoutId = null;
      completeShortEnding();
    }, ENDING_FADE_DURATION * 1000 + 50);
  }
  // 音量フェードは壁時計ベース（曲が実尺で終わって t が止まっても確実に下がる）
  const fadeElapsed = (performance.now() - endingFadeStartPerf) / 1000;
  if (mode === "audio") {
    player.volume = Math.max(0, 1 - fadeElapsed / ENDING_FADE_DURATION);
  }
  if (fadeElapsed >= ENDING_FADE_DURATION) {
    completeShortEnding();
  }
}

// ---------------------------------------------------------------------------
// buildGame：Worker 再起動＋設定適用（MIDI/音声共通）
// ---------------------------------------------------------------------------

function buildGame() {
  initWorker();
  renderKeyHints();
}

// Worker が無いときだけ構築する。リプレイや 2 回目以降の start では
// 既存の OffscreenCanvas + Worker を再利用し、Canvas×3 の破棄・再確保による
// メモリ/GPU スパイクを避ける。
function ensureWorker() {
  if (!worker) buildGame();
}

function beginPlayback() {
  clearTimeout(deathTimeoutId);
  deathTimeoutId = null;
  endingFadeStarted = false;
  endingFadeStartPerf = 0;
  if (endingFadeTimeoutId !== null) {
    clearTimeout(endingFadeTimeoutId);
    endingFadeTimeoutId = null;
  }
  // 音量の復元は startMidiPlayback() 内（midy.start() 直前）で行うため、
  // ここでは MIDI モードの setMasterVolume は不要。audio モードは即時復元で OK。
  if (mode === "audio") player.volume = 1;
  lastResult = emptyResult(laneNotes.length);
  worker.postMessage({ type: "start" });
  gamePhase = "playing";
  for (
    const s of [
      screenStart,
      screenReady,
      screenAnalyzing,
    ]
  ) {
    s.classList.add("hidden");
  }
  resultModal.hide();
  libraryModal.hide();
  soundFontModal.hide();
  settingsModal.hide();
  userInitiatedMidiPause = false;
  isPaused = false;
  showPlayHud();
  setWrapHeight(); // gamePhase="playing" になったので、ここでキャンバスを画面いっぱいに広げる
  updateTrackAttributionUI();
  startRaf();
  uiCanvas.focus({ preventScroll: true });
}

function applyConfigToGame(cfg) {
  const laneCountChanged = cfg.laneCount !== config.laneCount;
  const laneOrDiffChanged = laneCountChanged ||
    cfg.difficulty !== config.difficulty;
  // レーン数・遠近感・スクロール速度など描画構造に関わる変更だけ Worker を
  // 作り直す。色やキー割り当てだけなら updateOptions で足りるが、現状の
  // Worker 契約は setNotes 再送と reset を兼ねた rebuild の方が安全なため、
  // 構造変更時のみ rebuild、それ以外のプレイ中変更は rebuild せずオプション更新。
  const dprChanged = Number(cfg.maxPixelRatio) !== Number(config.maxPixelRatio);
  const structuralChanged = laneCountChanged ||
    dprChanged ||
    (cfg.perspectiveEnabled ?? true) !== (config.perspectiveEnabled ?? true) ||
    cfg.scrollSpeed !== config.scrollSpeed ||
    (cfg.laneOpacity ?? 0.35) !== (config.laneOpacity ?? 0.35) ||
    JSON.stringify(cfg.laneColors?.slice(0, cfg.laneCount)) !==
      JSON.stringify(config.laneColors?.slice(0, config.laneCount));

  config = cfg;
  // maxPixelRatio 変更時は実効 dpr を更新（構造変更時は後続の buildGame で反映）
  if (dprChanged) dpr = computeDpr();
  // MIDI サンプルキャッシュ粒度（再生中でも次回ボイス生成から効く）
  if (typeof midy !== "undefined" && CACHE_MODES.includes(config.cacheMode)) {
    midy.cacheMode = config.cacheMode;
  }

  if (mode === "audio" && laneOrDiffChanged) {
    // 音声モードは難易度/レーン数がビートマップ生成自体に影響するため、
    // 次回再生時に自動で再生成させる（今すぐの再生成はしない＝プレビューはthinNotesの範囲で反映）
    notesStale = true;
  }

  if (gamePhase === "playing" && !endingFadeStarted) {
    if (structuralChanged || laneOrDiffChanged) {
      // 譜面配置やレーン構造が変わるので Worker を立て直して notes を再送
      stopRaf();
      buildGame();
      applyNotes();
      worker.postMessage({ type: "start" });
      lastResult = emptyResult(laneNotes.length);
      startRaf();
      gamePhase = "playing";
    } else {
      // 色・オフセット等のみ：既存 Worker にパッチを送るだけ（Canvas 再確保しない）
      syncScoreColor();
      worker?.postMessage({
        type: "updateOptions",
        patch: {
          laneColors: config.laneColors.slice(0, config.laneCount),
          judgeOffset: (config.judgeOffset ?? 0) / 1000,
          uiColor: computeUiColor(),
          judgeLineColor: config.judgeLineColor || "",
          laneLineColor: config.laneLineColor || "",
          accentColor: config.accentColor || "",
          laneOpacity: config.laneOpacity ?? 0.35,
        },
      });
    }
  } else if (gamePhase !== "playing") {
    // 非プレイ中は構造が変わっていなくても設定プレビュー用に Worker を
    // 揃えておく。ただし既に Worker があり構造不変なら rebuild 不要。
    if (!worker || structuralChanged || laneOrDiffChanged) {
      buildGame();
    } else {
      syncScoreColor();
      worker.postMessage({
        type: "updateOptions",
        patch: {
          laneColors: config.laneColors.slice(0, config.laneCount),
          judgeOffset: (config.judgeOffset ?? 0) / 1000,
          uiColor: computeUiColor(),
          judgeLineColor: config.judgeLineColor || "",
          laneLineColor: config.laneLineColor || "",
          accentColor: config.accentColor || "",
          laneOpacity: config.laneOpacity ?? 0.35,
          scrollSpeed: config.scrollSpeed,
          perspective: (config.perspectiveEnabled ?? true) ? PERSPECTIVE : 0,
        },
      });
    }
    if (rawNotes.length > 0) applyNotes();
  }
  // gamePhase==="playing" && endingFadeStarted の場合は何もしない。
  // まもなく結果画面に遷移するため、ここで譜面を再構築して lastResult を
  // ゼロリセットすると、フェード完了時の showResult() が直前までのスコアを
  // 消してしまう（設定変更は次回プレイから反映されれば十分）。
  renderKeyHints();
}

// ---------------------------------------------------------------------------
// Screen management
// ---------------------------------------------------------------------------

function showScreen(name) {
  if (name === "settings") {
    settingsModal.show();
    return;
  }
  if (name === "library") {
    libraryModal.show();
    return;
  }
  gamePhase = name;
  screenStart.classList.toggle("hidden", name !== "start");
  screenReady.classList.toggle("hidden", name !== "ready");
  screenAnalyzing.classList.toggle("hidden", name !== "analyzing");
  if (name === "result") {
    resultModal.show();
  } else {
    resultModal.hide();
  }
  settingsModal.hide();
  libraryModal.hide();
  soundFontModal.hide();
  isPaused = false;
  hidePlayHud();
  setWrapHeight(); // gamePhase が変わったので、フルスクリーン⇄通常レイアウトを再計算する
  updateTrackAttributionUI();
}

function showResult() {
  if (gamePhase === "result") return; // 二重呼び出し防止
  clearTimeout(deathTimeoutId);
  deathTimeoutId = null;
  if (endingFadeTimeoutId !== null) {
    clearTimeout(endingFadeTimeoutId);
    endingFadeTimeoutId = null;
  }
  clearAudioLeadIn();
  // stop で描画ループを止める（finalize は ended 経路で済んでいる想定）。
  // 譜面配列自体は Worker に残し、リプレイ時の setNotes 再送（structured clone）を
  // 避ける。高負荷 MIDI ではこの clone がピークメモリを押し上げる一因になる。
  try {
    worker?.postMessage({ type: "stop", finalize: false });
  } catch (err) {
    console.error("worker stop failed:", err);
  }
  gamePhase = "result";
  isPaused = false;
  hidePlayHud();
  setWrapHeight(); // フルスクリーン表示から通常レイアウトに戻す

  // 表示用に整数へ丸める（内部は浮動小数で積算）
  lastResult.score = Math.round(Number(lastResult.score) || 0);

  const dead = Boolean(lastResult.dead);
  const judged = lastResult.dodge + lastResult.hit;
  const dodgeRate = judged > 0 ? (lastResult.dodge / judged) * 100 : 100;
  const rateStr = dodgeRate.toFixed(1);
  const rate = parseFloat(rateStr);
  // 死亡したら常に D。生き延びた場合は回避率でランク付けする。
  const [grade, cls] = dead
    ? ["D", "grade-D"]
    : rate >= 98
    ? ["S", "grade-S"]
    : rate >= 90
    ? ["A", "grade-A"]
    : rate >= 75
    ? ["B", "grade-B"]
    : ["C", "grade-C"];

  const gradeEl = document.getElementById("resultGrade");
  gradeEl.classList.remove(
    "grade-S",
    "grade-A",
    "grade-B",
    "grade-C",
    "grade-D",
  );
  gradeEl.classList.add(cls);
  gradeEl.textContent = dead ? "💀" : grade;
  document.getElementById("screenResultLabel").textContent = dead
    ? "GAME OVER"
    : "CLEAR!";
  document.getElementById("rScore").textContent = String(lastResult.score)
    .padStart(7, "0");
  document.getElementById("rAccuracy").textContent = rateStr + "%";
  document.getElementById("rCombo").textContent = lastResult.combo;
  document.getElementById("rDodge").textContent = lastResult.dodge;
  document.getElementById("rHit").textContent = lastResult.hit;
  document.getElementById("rHp").textContent = `${Math.ceil(lastResult.hp)} / ${lastResult.maxHp}`;
  document.getElementById("rProgress").textContent = dead
    ? Math.floor(lastResult.progress * 100) + "%"
    : "100%";
  const rDiff = document.getElementById("rDifficulty");
  const rLanes = document.getElementById("rLanes");
  const rScroll = document.getElementById("rScrollSpeed");
  if (rDiff) rDiff.textContent = config.difficulty;
  if (rLanes) rLanes.textContent = String(config.laneCount);
  if (rScroll) rScroll.textContent = String(config.scrollSpeed);

  showScreen("result");
}

// ---------------------------------------------------------------------------
// Key hints
// ---------------------------------------------------------------------------

// 操作キー: 左移動 = ← / A / F、右移動 = → / D / J（画面の左半分/右半分タップも同じ）
const MOVE_LEFT_KEYS = ["arrowleft", "a", "f"];
const MOVE_RIGHT_KEYS = ["arrowright", "d", "j"];
const KEY_LABELS = { arrowleft: "←", arrowright: "→" };

function renderKeyHints() {
  ["keyHintStart", "keyHintReady"].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerHTML = "";
    const groups = [
      [MOVE_LEFT_KEYS, config.laneColors[0]],
      [MOVE_RIGHT_KEYS, config.laneColors[config.laneCount - 1]],
    ];
    for (const [keys, color] of groups) {
      for (const key of keys) {
        const chip = document.createElement("span");
        chip.className = "lane-key-chip";
        chip.textContent = KEY_LABELS[key] ?? key.toUpperCase();
        // 色そのものは .lane-key-chip 側の CSS（color-mix + currentColor）で
        // テーマに応じたコントラストに調整されるので、ここではレーン色を変数で渡すだけ。
        chip.style.cssText = `--lane-color:${color}`;
        el.appendChild(chip);
      }
      // 左右のグループの間に少し間を空ける
      if (keys === MOVE_LEFT_KEYS) {
        const gap = document.createElement("span");
        gap.style.width = "0.75rem";
        el.appendChild(gap);
      }
    }
  });
}

// ---------------------------------------------------------------------------
// Play length toggle（SHORT: 120秒で強制終了 / ORIGINAL: 曲の最後まで）
// ---------------------------------------------------------------------------

const playLengthLabels = {
  short: document.querySelector(
    '#playLengthToggle label[for="playLengthShort"]',
  ),
  original: document.querySelector(
    '#playLengthToggle label[for="playLengthOriginal"]',
  ),
};

function formatDuration(seconds) {
  const s = Math.max(0, Math.round(seconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}:${String(r).padStart(2, "0")}`;
}

// ファイル読込直後（rawNotes/audioBuffer 確定後）に呼び、SHORT/ORIGINALの
// トグルラベルへ再生時間を反映する。元ファイルが SHORT_DURATION 未満の
// 場合は SHORT側にもその実尺を表示する。
function updatePlayLengthLabels() {
  const songDuration = getSongDuration();
  if (songDuration <= 0) return;
  const shortDuration = Math.min(SHORT_DURATION, songDuration);
  playLengthLabels.short.innerHTML = `SHORT<br>(${
    formatDuration(shortDuration)
  })`;
  playLengthLabels.original.innerHTML = `ORIGINAL<br>(${
    formatDuration(songDuration)
  })`;
}

document.querySelectorAll("#playLengthToggle input[data-length]").forEach(
  (input) => {
    input.addEventListener("change", () => {
      if (!input.checked) return;
      playLength = input.dataset.length;
      if (rawNotes.length > 0) applyNotes(); // noteCountLabel 更新のため
    });
  },
);

// ---------------------------------------------------------------------------
// Settings panel（MIDI/音声共通。背景・ダークモードも含む）
// ---------------------------------------------------------------------------

let configSnapshot = null;
// 設定パネルを開いてから実際にユーザーが値を変えたかどうか。
// 何も触らずに閉じたときは localStorage へ書き戻さない（不要な保存と、
// 途中で壊れた値が確定するのを防ぐ）。
let settingsDirty = false;

function readSettingsUI() {
  const gv = (id) => document.getElementById(id)?.value ?? "";
  const colors = [
    ...document.querySelectorAll("#laneColorPickers input[type=color]"),
  ]
    .map((i) => i.value);
  return {
    ...config,
    laneCount: parseInt(gv("laneCount"), 10) || 4,
    scrollSpeed: parseInt(gv("scrollSpeed"), 10) || 500,
    laneColors: colors,
    // accentColor 用の <input type=color> は常に何らかの16進値を持ってしまう
    // （空値を表現できない）ため、ユーザーが実際に触った場合だけ値を採用し、
    // 触っていなければ既存の config.accentColor（"" = 自動）をそのまま維持する。
    accentColor: document.getElementById("accentColor")?.dataset.touched === "1"
      ? gv("accentColor")
      : config.accentColor ?? "",
    // judgeLineColor も同様に、触った場合だけ採用（"" = uiColor に自動追従）。
    judgeLineColor:
      document.getElementById("judgeLineColor")?.dataset.touched === "1"
        ? gv("judgeLineColor")
        : config.judgeLineColor ?? "",
    laneLineColor:
      document.getElementById("laneLineColor")?.dataset.touched === "1"
        ? gv("laneLineColor")
        : config.laneLineColor ?? "",
    perspectiveEnabled:
      document.getElementById("perspectiveEnabled")?.checked ?? true,
    laneOpacity: parseFloat(
      document.getElementById("laneOpacity")?.value ?? "0.35",
    ),
    difficulty: document.getElementById("difficulty")?.value || "NORMAL",
    judgeOffset:
      parseInt(document.getElementById("judgeOffset")?.value ?? "0", 10) || 0,
    maxPixelRatio: parseFloat(
      document.getElementById("maxPixelRatio")?.value ?? "1",
    ) || 1,
    cacheMode: CACHE_MODES[
      Math.min(
        CACHE_MODES.length - 1,
        Math.max(0, parseInt(gv("cacheMode"), 10) || 0),
      )
    ],
  };
}

function openSettings() {
  // laneColors は参照共有だとプレビュー中の書き換えで
  // スナップショットまで汚染されるため、配列はコピーする。
  configSnapshot = {
    ...config,
    laneColors: [...config.laneColors],
  };
  settingsDirty = false;
  // 前回の未確定プレビューが残らないようにする
  pendingBackground = null;

  const sv = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.value = v;
  };
  const st = (id, v) => {
    const el = document.getElementById(id);
    if (el) el.textContent = v;
  };
  sv("laneCount", config.laneCount);
  st("laneCountVal", config.laneCount);
  sv("scrollSpeed", config.scrollSpeed);
  st("scrollSpeedVal", config.scrollSpeed);
  sv("maxPixelRatio", config.maxPixelRatio ?? 1);
  st("maxPixelRatioVal", config.maxPixelRatio ?? 1);
  {
    const idx = cacheModeIndex(config.cacheMode);
    sv("cacheMode", idx);
    st("cacheModeVal", cacheModeLabel(idx));
  }
  sv("difficulty", config.difficulty);
  const persEl = document.getElementById("perspectiveEnabled");
  if (persEl) persEl.checked = config.perspectiveEnabled ?? true;
  const joEl = document.getElementById("judgeOffset");
  if (joEl) {
    joEl.value = config.judgeOffset ?? 0;
    const jvEl = document.getElementById("judgeOffsetVal");
    if (jvEl) jvEl.textContent = (config.judgeOffset ?? 0) + "ms";
  }
  const loEl = document.getElementById("laneOpacity");
  if (loEl) {
    loEl.value = config.laneOpacity ?? 0.35;
    st("laneOpacityVal", (config.laneOpacity ?? 0.35).toFixed(2));
  }
  const acEl = document.getElementById("accentColor");
  if (acEl) {
    // <input type=color> は空値を表示できないため、未設定時は現在の文字色を
    // 算出して初期表示用に見せるだけにする（config.accentColor 自体は "" のまま）。
    acEl.value = config.accentColor ||
      rgbToHex(getComputedStyle(document.body).color) || "#ffc107";
    acEl.dataset.touched = "0"; // パネルを開き直すたびにリセット
  }
  const jlEl = document.getElementById("judgeLineColor");
  if (jlEl) {
    // 同様に未設定時は現在の文字色（uiColor 相当）を初期表示用に見せるだけにする。
    jlEl.value = config.judgeLineColor ||
      rgbToHex(getComputedStyle(document.body).color) || "#ffffff";
    jlEl.dataset.touched = "0";
  }
  const llEl = document.getElementById("laneLineColor");
  if (llEl) {
    llEl.value = config.laneLineColor ||
      rgbToHex(getComputedStyle(document.body).color) || "#ffffff";
    llEl.dataset.touched = "0";
  }

  document.getElementById("audioDiffNote")?.classList.toggle(
    "hidden",
    mode !== "audio",
  );

  const colorInputs = document.querySelectorAll(
    "#laneColorPickers input[type=color]",
  );
  for (let l = 0; l < colorInputs.length; l++) {
    colorInputs[l].value = config.laneColors[l] ??
      DEFAULT_CONFIG.laneColors[l % DEFAULT_CONFIG.laneColors.length];
  }

  // 値の代入で input/change が飛ぶ環境向けに、UI 反映後にもう一度クリアする
  settingsDirty = false;
  showScreen("settings");
}

function onSettingsInput() {
  settingsDirty = true;
  applyConfigToGame(readSettingsUI());
  // プレビュー用にメモリ上の config は更新するが、localStorage への確定保存は
  // 「適用して閉じる」時のみ行う。キャンセルで閉じたときに不完全な設定が
  // 永続化されるのを防ぐ。
}

function applySettings() {
  applyConfigToGame(readSettingsUI());
  // 背景はプレビューのみ即時反映しているため、ここで初めて永続化する
  commitPendingBackground();
  saveConfig(config);
  configSnapshot = null; // 適用済みなので hide.bs.modal 側の巻き戻しを無効化
  settingsDirty = false;
  settingsModal.hide();
}

// ✕ボタン・キャンセルボタン（どちらも data-bs-dismiss="modal"）・背景クリック・
// Escキー、すべて Bootstrap モーダルの hide.bs.modal に集約されるので、
// 未適用の変更を巻き戻す処理はここに一本化する。
// （適用時は applySettings() が configSnapshot を先に null にしているので二重には走らない）
screenSettings.addEventListener("hide.bs.modal", () => {
  if (configSnapshot) {
    if (settingsDirty) {
      // ライブプレビューで書き換えた config をスナップショットへ戻し、
      // 触る前の値を localStorage にも書き戻す。
      applyConfigToGame(configSnapshot);
      saveConfig(configSnapshot);
      revertPendingBackground(configSnapshot.backgroundPreset ?? "");
    }
    // 何も変更していない場合はメモリも storage も触らない
    configSnapshot = null;
    settingsDirty = false;
  }
});

const settingsPanelEl = document.getElementById("settingsPanel");
settingsPanelEl.addEventListener("input", onSettingsInput);
settingsPanelEl.addEventListener("change", onSettingsInput);

document.getElementById("accentColor")?.addEventListener("input", (e) => {
  e.target.dataset.touched = "1";
});

document.getElementById("btnResetAccentColor")?.addEventListener(
  "click",
  () => {
    settingsDirty = true;
    applyConfigToGame({ ...readSettingsUI(), accentColor: "" });
    const acEl = document.getElementById("accentColor");
    if (acEl) {
      acEl.value = rgbToHex(getComputedStyle(document.body).color) || "#ffc107";
      acEl.dataset.touched = "0";
    }
  },
);

document.getElementById("judgeLineColor")?.addEventListener("input", (e) => {
  e.target.dataset.touched = "1";
});

document.getElementById("btnResetJudgeLineColor")?.addEventListener(
  "click",
  () => {
    settingsDirty = true;
    applyConfigToGame({ ...readSettingsUI(), judgeLineColor: "" });
    const jlEl = document.getElementById("judgeLineColor");
    if (jlEl) {
      jlEl.value = rgbToHex(getComputedStyle(document.body).color) || "#ffffff";
      jlEl.dataset.touched = "0";
    }
  },
);

document.getElementById("laneLineColor")?.addEventListener("input", (e) => {
  e.target.dataset.touched = "1";
});

document.getElementById("btnResetLaneLineColor")?.addEventListener(
  "click",
  () => {
    settingsDirty = true;
    applyConfigToGame({ ...readSettingsUI(), laneLineColor: "" });
    const llEl = document.getElementById("laneLineColor");
    if (llEl) {
      llEl.value = rgbToHex(getComputedStyle(document.body).color) || "#ffffff";
      llEl.dataset.touched = "0";
    }
  },
);

[
  ["laneCount", "laneCountVal"],
  ["scrollSpeed", "scrollSpeedVal"],
  ["laneOpacity", "laneOpacityVal"],
  ["judgeOffset", "judgeOffsetVal"],
  ["maxPixelRatio", "maxPixelRatioVal"],
].forEach(([sid, lid]) => {
  document.getElementById(sid)?.addEventListener("input", (e) => {
    const el = document.getElementById(lid);
    if (el) {
      el.textContent = sid === "laneOpacity"
        ? parseFloat(e.target.value).toFixed(2)
        : sid === "judgeOffset"
        ? e.target.value + "ms"
        : e.target.value;
    }
  });
});
document.getElementById("cacheMode")?.addEventListener("input", (e) => {
  const el = document.getElementById("cacheModeVal");
  if (el) el.textContent = cacheModeLabel(parseInt(e.target.value, 10) || 0);
});

function goToStartScreen() {
  if (gamePhase === "playing") stopRaf();
  stopAllPlayback();
  clearTrackMeta();
  showScreen("start");
}
document.getElementById("btnChangeFileReady").addEventListener(
  "click",
  goToStartScreen,
);
document.getElementById("btnChangeFileResult").addEventListener(
  "click",
  goToStartScreen,
);
document.getElementById("btnSettings").addEventListener("click", openSettings);
document.getElementById("btnApplySettings").addEventListener(
  "click",
  applySettings,
);

// 設定のリセット: localStorage の config / テーマと、IndexedDB（背景ファイル）を
// まるごと消してリロードする。個別キーの削除ではなく deleteDatabase() で
// データベースごと消すことで、将来 store が増えても取りこぼさないようにする。
document.getElementById("btnResetAllSettings")?.addEventListener(
  "click",
  async () => {
    localStorage.removeItem("FlipFlapDodgeConfig");
    localStorage.removeItem("darkMode");
    try {
      await new Promise((resolve, reject) => {
        const req = indexedDB.deleteDatabase(BG_DB_NAME);
        req.onsuccess = () => resolve();
        req.onerror = () => reject(req.error);
        // 他タブでDBが開いたままだと即座には消えないが、リロード自体は続行する
        req.onblocked = () => resolve();
      });
    } catch (err) {
      console.error("IndexedDB のリセットに失敗:", err);
    }
    location.reload();
  },
);

// ---------------------------------------------------------------------------
// Dark mode
// ---------------------------------------------------------------------------

function toggleDarkMode() {
  const html = document.documentElement;
  const newTheme = html.getAttribute("data-bs-theme") === "dark"
    ? "light"
    : "dark";
  html.setAttribute("data-bs-theme", newTheme);
  localStorage.setItem("darkMode", newTheme);
}

function changeLang() {
  const langObj = document.getElementById("lang");
  const lang = langObj.options[langObj.selectedIndex].value;
  location.href = `/flip-flap-notes/${lang}/`;
}

document.getElementById("toggleDarkMode").addEventListener("click", () => {
  toggleDarkMode();
  // ゲーム進行中でもレーン区切り線・判定ライン・HUD文字が見えなくならないよう、
  // 稼働中の worker にも新しいテーマ文字色を反映する
  // （rhythm-game-worker.js の "updateOptions" は msg.patch を読む契約なので合わせる）。
  syncScoreColor();
  worker?.postMessage({
    type: "updateOptions",
    patch: { uiColor: computeUiColor() },
  });
});
document.getElementById("lang").onchange = changeLang;

// ---------------------------------------------------------------------------
// Keyboard input（MIDI/音声共通）
// ---------------------------------------------------------------------------

document.addEventListener("keydown", (e) => {
  if (
    e.repeat || e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA"
  ) return;
  if (e.code === "Space") {
    if (gamePhase === "playing") {
      e.preventDefault(); // ページスクロールを防ぐ
      togglePause();
    } else if (gamePhase === "ready" || gamePhase === "result") {
      // btnBigStart / btnBigReplay と同じ操作をキーボードからも行えるようにする
      e.preventDefault();
      startOrReplay();
    }
    return;
  }
  if (gamePhase !== "playing") return;
  const key = e.key.toLowerCase();
  const isLeft = MOVE_LEFT_KEYS.includes(key);
  const isRight = !isLeft && MOVE_RIGHT_KEYS.includes(key);
  if (!isLeft && !isRight) return;
  e.preventDefault(); // 矢印キーでのページスクロールを防ぐ
  if (isPaused) return;
  worker?.postMessage({ type: "moveLane", dir: isLeft ? -1 : 1 });
}, { capture: true });

// ---------------------------------------------------------------------------
// タッチ・ポインター入力（MIDI/音声共通）
// 画面の左半分をタップすると 1 レーン左へ、右半分をタップすると 1 レーン右へ移動する。
// ---------------------------------------------------------------------------

function bindPointerEvents(canvas) {
  canvas.addEventListener("pointerdown", (e) => {
    if (gamePhase !== "playing" || isPaused) return;
    e.preventDefault();
    canvas.focus({ preventScroll: true });
    const rect = canvas.getBoundingClientRect();
    const dir = e.clientX - rect.left < rect.width / 2 ? -1 : 1;
    worker?.postMessage({ type: "moveLane", dir });
  });
}
bindPointerEvents(uiCanvas);

// ---------------------------------------------------------------------------
// 一時停止（スペースキー / 画面左上のポーズボタン、MIDI/音声共通）
//
// 実際の一時停止/再開の状態管理は、既存の midy "paused"/"resumed" イベントと
// player の "pause"/"play" イベント（下の方の各リスナー内）に一本化してある。
// ここでは「操作のきっかけ」を作るだけ。
// ---------------------------------------------------------------------------

function updatePauseUi(paused) {
  isPaused = paused;
  pauseOverlay.classList.toggle("hidden", !paused);
  btnPause.innerHTML = paused ? ICON_PLAY : ICON_PAUSE;
}

function scheduleAudioLeadInEnd(remainingSec) {
  if (_audioLeadInTimeoutId !== null) {
    clearTimeout(_audioLeadInTimeoutId);
    _audioLeadInTimeoutId = null;
  }
  const ms = Math.max(0, remainingSec * 1000);
  _audioLeadInTimeoutId = setTimeout(() => {
    _audioLeadInTimeoutId = null;
    if (gamePhase !== "playing" || isPaused || !_audioLeadIn) return;
    _audioLeadIn = false;
    player.currentTime = 0;
    player.play().catch((err) => console.error("player.play failed:", err));
  }, ms);
}

// ---------------------------------------------------------------------------
// iOS 背面 + ポーズ安全化
// 曲切り替え後などに midy の状態がずれていると、pause 時の tick/stopped が
// 「曲終了」扱いになりスコア画面へ飛ぶ。ユーザーポーズでは isPaused を先に立て、
// ended/stopped を無視する。
// ---------------------------------------------------------------------------

let resumeGuardUntil = 0;

function kickAudioContextSync() {
  if (!audioContext) return;
  try {
    const p = audioContext.resume();
    if (p && typeof p.catch === "function") {
      p.catch((err) => console.error("audioContext.resume failed:", err));
    }
  } catch (err) {
    console.error("audioContext.resume failed:", err);
  }
}

function pauseForBackground() {
  if (gamePhase !== "playing" || isPaused) return;
  if (performance.now() < resumeGuardUntil) return;

  try {
    _pausedAt = currentGameTime();
  } catch {
    /* ignore */
  }
  stopRaf();
  updatePauseUi(true);

  if (mode === "midi") {
    if (!midy.isPaused) {
      try {
        userInitiatedMidiPause = true;
        midy.pause();
      } catch (err) {
        console.error("midy.pause on background failed:", err);
        userInitiatedMidiPause = false;
      }
    }
  } else if (mode === "audio") {
    if (_audioLeadIn) {
      if (_audioLeadInTimeoutId !== null) {
        clearTimeout(_audioLeadInTimeoutId);
        _audioLeadInTimeoutId = null;
      }
    } else if (!player.paused) {
      try {
        player.pause();
      } catch (err) {
        console.error("player.pause on background failed:", err);
      }
    }
  }
}

function resumeFromPause() {
  resumeGuardUntil = performance.now() + 2000;
  userInitiatedMidiPause = false;

  // 同期で AudioContext を起こす（iOS はジェスチャ内 resume が必須）
  kickAudioContextSync();

  _resumeBaseGameTime = _pausedAt;
  _resumeBasePerf = performance.now();
  _resumeStabilizeMinUntil = _resumeBasePerf + RESUME_STABILIZE_MIN_MS;
  _resumeStabilizeMaxUntil = _resumeBasePerf + RESUME_STABILIZE_MAX_MS;

  updatePauseUi(false);
  startRaf();

  if (mode === "midi") {
    try {
      if (midy.isPaused) {
        const result = midy.resume();
        if (result && typeof result.then === "function") {
          result.then(
            () => {
              _resumeBaseGameTime = currentGameTime();
              _resumeBasePerf = performance.now();
              _resumeStabilizeMinUntil = _resumeBasePerf +
                RESUME_STABILIZE_MIN_MS;
              _resumeStabilizeMaxUntil = _resumeBasePerf +
                RESUME_STABILIZE_MAX_MS;
            },
            (err) => console.error("midy.resume failed:", err),
          );
        }
      }
    } catch (err) {
      console.error("midy.resume failed:", err);
    }
    kickAudioContextSync();
    return;
  }

  if (mode === "audio") {
    if (_audioLeadIn) {
      _audioLeadInStartPerf = performance.now() -
        (_pausedAt + START_DELAY) * 1000;
      scheduleAudioLeadInEnd(Math.max(0, -_pausedAt));
      return;
    }
    player.play().catch((err) => console.error("player.play failed:", err));
  }
}

function togglePause() {
  if (gamePhase !== "playing") return;

  // UI の isPaused を正とする（midy.isPaused だけ見ると再開扱いになる事故を防ぐ）
  if (isPaused) {
    resumeFromPause();
    return;
  }

  // ---- ユーザーポーズ: 先に isPaused を立ててから音源を止める ----
  // midy.pause や worker tick が ended/stopped を発火してもスコア画面に行かない。
  try {
    _pausedAt = currentGameTime();
  } catch {
    _pausedAt = 0;
  }
  stopRaf();
  updatePauseUi(true);

  if (mode === "midi") {
    try {
      userInitiatedMidiPause = true;
      if (!midy.isPaused) {
        midy.pause();
      }
    } catch (err) {
      console.error("midy.pause failed:", err);
      userInitiatedMidiPause = false;
    }
  } else if (mode === "audio") {
    if (_audioLeadIn) {
      if (_audioLeadInTimeoutId !== null) {
        clearTimeout(_audioLeadInTimeoutId);
        _audioLeadInTimeoutId = null;
      }
      return;
    }
    if (!player.paused) {
      player.pause();
    }
  }
}
btnPause.addEventListener("click", (e) => {
  e.stopPropagation();
  togglePause();
});

// ---------------------------------------------------------------------------
// モード切り替え
// ---------------------------------------------------------------------------

function clearAudioLeadIn() {
  _audioLeadIn = false;
  if (_audioLeadInTimeoutId !== null) {
    clearTimeout(_audioLeadInTimeoutId);
    _audioLeadInTimeoutId = null;
  }
}

function stopAllPlayback() {
  stopRaf();
  if (endingFadeTimeoutId !== null) {
    clearTimeout(endingFadeTimeoutId);
    endingFadeTimeoutId = null;
  }
  endingFadeStarted = false;
  clearAudioLeadIn();
  try {
    if (!midy.isPaused) midy.pause();
  } catch (err) {
    console.error("midy.pause failed:", err);
  }
  try {
    if (!player.paused) player.pause();
  } catch (err) {
    console.error("player.pause failed:", err);
  }
  try {
    worker?.postMessage({ type: "stop", finalize: false });
  } catch {
    /* ignore */
  }
}

function switchMode(next) {
  if (mode === next) return;
  stopAllPlayback();
  mode = next;
  // 前のモード／曲向けのキャッシュ予熱が走っていたら無効化する
  midiCacheWarmupToken++;
  midiCacheWarmupPromise = null;

  // html[data-mode] は readyHintAudio（音声モードの案内）だけがCSS側で参照している。
  // start画面のタイトル/説明はモードに関わらず常に固定表示。
  document.documentElement.dataset.mode = mode;

  rawNotes = [];
  laneNotes = [];
  lastApplyKey = "";
  notesPostedToWorker = false;
  notesReady = false;
  notesStale = true;
  clearTrackMeta();
  buildGame();
  showScreen("start");
  setTimeout(setWrapHeight, 30);
}

// ---------------------------------------------------------------------------
// MIDI playback
// ---------------------------------------------------------------------------

const audioContext = new AudioContext();
const midy = new Midy(audioContext);
midy.cacheMode = CACHE_MODES.includes(config.cacheMode)
  ? config.cacheMode
  : "chunk";
midy.startDelay = START_DELAY;

const SOUNDFONT_BASE = "https://soundfonts.pages.dev/";
// 現在選択中のサウンドフォントのベースURL（ディレクトリ）。
// 例: "https://soundfonts.pages.dev/GeneralUser_GS_v2.0.3"
// サウンドフォントライブラリで選択が変わると soundFontURL だけ更新し、
// 実際の読み込みは次回の startMidiPlayback() 時にまとめて行う。
let soundFontURL = SOUNDFONT_BASE + "GeneralUser_GS_v2.0.3";

// 読み込み済みの楽器はスキップしつつ、今回のMIDIで実際に使われている楽器に
// 対応する .sf3 のパス一覧を作る。
function getSoundFontPaths() {
  const paths = [];
  for (const instrument of midy.instruments) {
    const [bank, program] = instrument.split(":");
    const bankNumber = Number(bank);
    const programNumber = Number(program);
    const index = midy.soundFontTable[programNumber]?.[bankNumber];
    if (index !== undefined) continue;
    paths.push(`${soundFontURL}/${bank}/${program}.sf3`);
  }
  return paths;
}

// MIDI 選択直後～START ボタンを押すまでの間に、バックグラウンドで
// SoundFont読み込み／ボイスID解決／サンプルデコードを終わらせておく。
// これにより startMidiPlayback() 実行時（＝START押下時）の体感的な重さを
// 下げる。warmupMidiCache() は選曲のたびに呼び直され、古い呼び出しの
// 処理が完了しても意味がないよう世代トークンで無効化する。
let midiCacheWarmupPromise = null;
let midiCacheWarmupToken = 0;

function warmupMidiCache() {
  const token = ++midiCacheWarmupToken;
  const promise = (async () => {
    try {
      // 1. 同期・通信なし（SoundFont が既に読み込み済みの楽器のみの場合）
      await midy.loadSoundFont(getSoundFontPaths());
      if (token !== midiCacheWarmupToken) return;
      midy.cacheVoiceIds();
      if (token !== midiCacheWarmupToken) return;
      // 2. デコード。未取得サンプルがあると通信しうる
      await midy.preloadSamples();
      // await midy.prewarmSimpleNoteCache(); // 任意。CPU と OAC のみ
    } catch (err) {
      // ここで失敗しても致命的ではない（startMidiPlayback() 側で
      // 通常どおり loadSoundFont からやり直す）ので握りつぶしてログのみ。
      console.error("MIDI cache warmup failed:", err);
    }
  })();
  midiCacheWarmupPromise = promise;
  return promise;
}

// 別の曲を読み込む前（loadMIDIBytes / switchMode）に確実に停止させる。
// SHORT終了後の再プレイは pause()+resume() で行うためここは通らない。
async function ensureMidiStopped() {
  if (!midy.isPlaying && !midy.isPaused) return;
  try {
    await midy.stop();
  } catch (err) {
    console.error("midy.stop failed:", err);
  }
}

// startMidiPlayback() で一度でも midy.start() を呼んだかどうか。
// 「一度も再生していない曲への初回 start」と「自然終了後のリプレイ start」を
// 区別するために使う（詳細は startMidiPlayback() 内のコメント参照）。
let midiHasStartedOnce = false;

async function startMidiPlayback() {
  // completeShortEnding() / ORIGINAL自然終了の systemPauseMidi() がまだ
  // 進行中なら、まずそれの完了を待つ。ここを待たずに midy.isPaused を見ると、
  // 「pause() の完了直前（isPlaying/isPaused がまだどちらも false 寄りの
  // 遷移中）」を誤ってスナップショットしてしまい、以降の分岐が本来と違う
  // 経路（かつ資源再読み込みを伴う遅い stop+start）に入ってしまう。
  // これが、曲の実尺が SHORT_DURATION / ノート消化タイミングと際どく重なる
  // 曲（例: 1:22 の曲）でリプレイ時にゲームが始まらず、スペースキーで
  // ようやく動くように見えていた不具合の主因だった。
  if (systemPausePromise) {
    try {
      await systemPausePromise;
    } catch (err) {
      console.error("pending systemPauseMidi failed:", err);
    }
  }
  userInitiatedMidiPause = false;

  // SHORT終了後は pause() で止めているので resume() で先頭から再開できる。
  // キャッシュが保持されているため SoundFont の再読み込みも不要。
  // 上で systemPausePromise を待ち終えているため、ここでの midy.isPaused は
  // 「pause 完了直後の安定した値」であり、以降の分岐を安心して選べる。
  if (midy.isPaused) {
    try {
      midy.seekTo(0);
      midy.setMasterVolume(1, audioContext.currentTime);
      await midy.resume();
    } catch (err) {
      console.error("midy.resume failed:", err);
    }
    return;
  }
  // ORIGINAL 完走時や、曲が SHORT_DURATION 未満で自然終了したときは
  // pause() ではなく stop 相当の自然終了（isPlaying=false, isPaused=false）になる。
  // この状態から ensureMidiStopped() を呼んでも、そのガード
  // 「!isPlaying && !isPaused なら何もしない」に引っかかって
  // 実際には midy.stop() が一度も呼ばれない。
  // そのため内部の再生状態（スケジュール済みノート／アクティブボイス等）が
  // リセットされないまま次の midy.start() が積み重なり、2回目以降の
  // リプレイで処理が追いつかずハングする原因になっていた。
  // 「一度でも再生したことがある」場合は、isPlaying/isPaused の値に関わらず
  // 必ず stop() してから start() し直す（初回の未再生インスタンスに対しては
  // 従来通り stop() を呼ばない＝ensureMidiStopped() のガードを維持する）。
  if (midiHasStartedOnce) {
    try {
      await midy.stop();
    } catch (err) {
      console.error("midy.stop failed:", err);
    }
  } else {
    await ensureMidiStopped();
  }
  // warmupMidiCache() がバックグラウンドで loadSoundFont / cacheVoiceIds /
  // preloadSamples まで済ませてくれていれば、ここでは完了を待つだけで済む。
  // まだ warmup していない（または失敗した）場合は、従来どおりここで
  // SoundFont読み込みからやり直す。
  if (midiCacheWarmupPromise) {
    try {
      await midiCacheWarmupPromise;
    } catch (err) {
      console.error("midiCacheWarmupPromise failed:", err);
    }
  } else {
    await midy.loadSoundFont(getSoundFontPaths());
    midy.cacheVoiceIds();
    await midy.preloadSamples();
  }
  midy.setMasterVolume(1, audioContext.currentTime);
  // preload はここまでで完了済みなので、start() 側の内部 preload はスキップする
  await midy.start({ preload: false });
  midiHasStartedOnce = true;
}

async function loadMIDIBytes(bytes, meta = null) {
  switchMode("midi");
  await ensureMidiStopped();
  await midy.loadMIDI(bytes);
  rawNotes = extractNotesFromMidy(midy);
  lastApplyKey = "";
  notesPostedToWorker = false;
  // switchMode() が clearTrackMeta() するので、MIDI 読込後に改めて設定する
  setTrackMeta(meta);
  buildGame();
  applyNotes(true);
  updatePlayLengthLabels();
  showScreen("ready");
  // START が押されるまでの間にバックグラウンドでキャッシュを温めておく
  warmupMidiCache();
}

// ---------------------------------------------------------------------------
// 統合ファイル選択：拡張子/MIMEタイプから MIDI / SoundFont / 音声 を自動判別
// ---------------------------------------------------------------------------

const AUDIO_EXTS = new Set([
  "mp3",
  "wav",
  "ogg",
  "oga",
  "m4a",
  "aac",
  "flac",
  "opus",
  "weba",
  "wma",
]);

function detectFileKind(file) {
  const ext = file.name.split(".").pop().toLowerCase();
  if (ext === "sf2" || ext === "sf3") return "soundfont";
  if (ext === "mid" || ext === "midi") return "midi";
  if (file.type?.startsWith("audio/")) return "audio";
  if (AUDIO_EXTS.has(ext)) return "audio";
  return null;
}

async function loadFile(file) {
  if (!file) return;
  const kind = detectFileKind(file);
  if (kind === "soundfont") {
    const buf = await file.arrayBuffer();
    await midy.loadSoundFont(new Uint8Array(buf));
    // SoundFont単体ではモードは変えない（既にMIDIが読み込み済みならそのまま反映される）
    return;
  }
  if (kind === "midi") {
    const buf = await file.arrayBuffer();
    // ローカル MIDI にはライブラリ由来の著作権情報がない（ファイル名のみ表示しない）
    await loadMIDIBytes(new Uint8Array(buf), null);
    return;
  }
  if (kind === "audio") {
    await loadAudioFile(file);
    return;
  }
  alert(t("unsupportedFileType"));
}

document.getElementById("selectFile").addEventListener(
  "click",
  () => document.getElementById("inputFile").click(),
);
document.getElementById("inputFile").addEventListener("change", (e) => {
  loadFile(e.target.files[0]);
  e.target.value = "";
});
document.addEventListener("paste", (e) => {
  const f = e.clipboardData?.items[0]?.getAsFile();
  if (f) loadFile(f);
});

const selectPanel = document.getElementById("selectPanel");
let dragN = 0;
selectPanel.addEventListener("dragenter", (e) => {
  e.preventDefault();
  if (++dragN === 1) {
    selectPanel.classList.add("drag-active");
  }
});
selectPanel.addEventListener("dragleave", (e) => {
  e.preventDefault();
  if (--dragN === 0) {
    selectPanel.classList.remove("drag-active");
  }
});
selectPanel.addEventListener("dragover", (e) => {
  e.preventDefault();
  e.dataTransfer.dropEffect = "copy";
});
selectPanel.addEventListener("drop", (e) => {
  e.preventDefault();
  dragN = 0;
  selectPanel.classList.remove("drag-active");
  loadFile(e.dataTransfer.files[0]);
});

// ---------------------------------------------------------------------------
// MIDI library（Bootstrap modal 内に MidiLibrary で一覧表示）
// ---------------------------------------------------------------------------

const midiLibrary = new MidiLibrary({
  table: "libraryTable",
  pagination: "libraryPagination",
  columns: "libraryColumns",
  collections: "libraryCollections",
  instruments: "libraryInstruments",
  lang: ["ja", "en"].includes(htmlLang) ? htmlLang : "en",
  onSelect: async (row) => {
    const buf = await (await fetch(`https://midi-db.pages.dev/${row.file}`))
      .arrayBuffer();
    await loadMIDIBytes(new Uint8Array(buf), trackMetaFromLibraryRow(row));
    libraryModal.hide();
  },
});
midiLibrary.load();

// ---------------------------------------------------------------------------
// 楽曲メタデータ（タイトル / 作者 / サイト / ライセンス）表示
// MIDI ライブラリ由来の曲で著作権表示を満たすために、ready / playing / result
// の間は画面上部に表示する。ローカルファイル読込時はクリアする。
// ---------------------------------------------------------------------------

/** @type {{ title: string, composer: string, siteName: string, web: string, license: string } | null} */
let currentTrackMeta = null;

function isProbablyUrl(s) {
  if (!s) return false;
  try {
    const u = new URL(s);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

function escapeHtml(s) {
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

/** MIDI ライブラリ行 + コレクション情報から表示用メタデータを組み立てる */
function trackMetaFromLibraryRow(row) {
  if (!row) return null;
  const collectionId = String(row.file || "").split("/")[0] || "";
  const col = collectionId ? midiLibrary.collections.get(collectionId) : null;
  const web = row.web || col?.web || "";
  const siteName = row.collection || col?.name || collectionId || "";
  const license = row.license || col?.license || "";
  const title = row.title || "";
  const composer = row.composer || col?.composer || "";
  if (!title && !composer && !siteName && !license) return null;
  return { title, composer, siteName, web, license };
}

function clearTrackMeta() {
  currentTrackMeta = null;
  updateTrackAttributionUI();
}

function setTrackMeta(meta) {
  currentTrackMeta = meta && (meta.title || meta.composer || meta.siteName ||
      meta.license)
    ? {
      title: meta.title || "",
      composer: meta.composer || "",
      siteName: meta.siteName || "",
      web: meta.web || "",
      license: meta.license || "",
    }
    : null;
  updateTrackAttributionUI();
}

function updateTrackAttributionUI() {
  const root = document.getElementById("trackAttribution");
  const titleEl = document.getElementById("trackAttrTitle");
  const metaEl = document.getElementById("trackAttrMeta");
  if (!root || !titleEl || !metaEl) return;

  const meta = currentTrackMeta;
  // スタート画面では隠す。ready / playing / result / analyzing で表示
  const visible = !!meta && gamePhase !== "start";
  root.classList.toggle("hidden", !visible);
  if (!meta) {
    titleEl.textContent = "";
    metaEl.innerHTML = "";
    // attribution の表示/非表示で #hudStack の高さが変わるので、combo が
    // 重ならないよう topInset を再計算させる（縦積みの折返しは CSS Grid が
    // 自動でやるので、ここでは resizeCanvases() だけでよい）。
    if (worker) resizeCanvases();
    return;
  }

  titleEl.textContent = meta.title || "Untitled";

  const parts = [];
  if (meta.composer) {
    parts.push(`<span>${escapeHtml(meta.composer)}</span>`);
  }
  if (meta.web && isProbablyUrl(meta.web)) {
    const label = escapeHtml(meta.siteName || meta.web);
    parts.push(
      `<span class="sep"><a href="${
        escapeHtml(meta.web)
      }" target="_blank" rel="noopener noreferrer">${label}</a></span>`,
    );
  } else if (meta.siteName) {
    parts.push(`<span class="sep">${escapeHtml(meta.siteName)}</span>`);
  }
  if (meta.license) {
    if (isProbablyUrl(meta.license)) {
      parts.push(
        `<span class="sep"><a href="${
          escapeHtml(meta.license)
        }" target="_blank" rel="noopener noreferrer">License</a></span>`,
      );
    } else {
      parts.push(`<span class="sep">${escapeHtml(meta.license)}</span>`);
    }
  }
  metaEl.innerHTML = parts.join("");
  // 表示後に #hudStack の高さが変わるので、combo が重ならないよう
  // topInset を再計算させる（縦積みの折返し自体は CSS Grid 側で完結する）。
  if (worker) resizeCanvases();
}

// ---------------------------------------------------------------------------
// 結果画面: MIDI ライブラリから 1 分以上の楽曲をランダム選曲
// ---------------------------------------------------------------------------

/** "M:SS" / "H:MM:SS" / 秒数 を秒に変換。パース不可は 0。 */
function parseMidiLibraryTime(timeStr) {
  if (timeStr == null || timeStr === "") return 0;
  if (typeof timeStr === "number" && Number.isFinite(timeStr)) return timeStr;
  const s = String(timeStr).trim();
  if (/^\d+(\.\d+)?$/.test(s)) return Number(s);
  const parts = s.split(":").map((p) => Number(p));
  if (parts.some((n) => !Number.isFinite(n))) return 0;
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

const RANDOM_MIDI_MIN_SECONDS = 60;
let randomMidiBusy = false;

function randomMidiButtons() {
  return [
    document.getElementById("btnRandomMidi"),
    document.getElementById("btnRandomMidiStart"),
  ].filter(Boolean);
}

function setRandomMidiButtonsBusy(busy) {
  for (const btn of randomMidiButtons()) {
    btn.disabled = busy;
    btn.textContent = busy ? t("randomMidiLoading") : t("randomMidi");
  }
}

async function playRandomLongMidi() {
  if (randomMidiBusy) return;
  const data = midiLibrary.fullData;
  if (!data || data.length === 0) {
    alert(t("randomMidiStillLoading"));
    return;
  }
  const candidates = data.filter(
    (row) =>
      row?.file && parseMidiLibraryTime(row.time) >= RANDOM_MIDI_MIN_SECONDS,
  );
  if (candidates.length === 0) {
    alert(t("randomMidiNoCandidates"));
    return;
  }
  const row = candidates[Math.floor(Math.random() * candidates.length)];
  randomMidiBusy = true;
  setRandomMidiButtonsBusy(true);
  try {
    const buf = await (await fetch(`https://midi-db.pages.dev/${row.file}`))
      .arrayBuffer();
    await loadMIDIBytes(new Uint8Array(buf), trackMetaFromLibraryRow(row));
  } catch (err) {
    console.error("Random MIDI load failed:", err);
    alert(t("randomMidiLoadFailedPrefix") + (err?.message || err));
  } finally {
    randomMidiBusy = false;
    setRandomMidiButtonsBusy(false);
  }
}

for (const id of ["btnRandomMidi", "btnRandomMidiStart"]) {
  document.getElementById(id)?.addEventListener("click", () => {
    playRandomLongMidi().catch((err) =>
      console.error("playRandomLongMidi failed:", err)
    );
  });
}

// ---------------------------------------------------------------------------
// SoundFont library（Bootstrap modal 内の一覧から選択。ラジオボタンなので
// 現在選択中の SoundFont が一目でわかる）
// ---------------------------------------------------------------------------

let soundFontListLoaded = false;

async function loadSoundFontLibrary() {
  const el = document.getElementById("soundFontLibraryList");
  try {
    const list = await (await fetch(`${SOUNDFONT_BASE}list.json`)).json();
    el.innerHTML = "";
    list.forEach((sf, i) => {
      const id = `soundFontLibraryItem-${i}`;
      const checked = sf.name === "GeneralUser_GS_v2.0.3";
      const wrap = document.createElement("div");
      wrap.className = "form-check";
      wrap.innerHTML =
        `<input class="form-check-input" type="radio" name="soundFontLibrary" id="${id}" value="${sf.name}" ${
          checked ? "checked" : ""
        }>` +
        `<label class="form-check-label" for="${id}">${sf.name}</label>`;
      el.appendChild(wrap);
      if (checked) soundFontURL = SOUNDFONT_BASE + sf.name;
    });
    soundFontListLoaded = true;
  } catch (err) {
    console.error("Failed to load SoundFont library:", err);
    el.textContent = t("soundFontLoadFailed");
  }
}

document.getElementById("soundFontLibraryList").addEventListener(
  "change",
  (e) => {
    if (e.target.name !== "soundFontLibrary") return;
    soundFontURL = SOUNDFONT_BASE + e.target.value;
    // SoundFont を切り替えたら、そのぶんキャッシュも新しいものに温め直す
    if (mode === "midi" && rawNotes.length > 0) warmupMidiCache();
  },
);

document.getElementById("openSoundFontLibrary").addEventListener(
  "click",
  () => {
    if (!soundFontListLoaded) loadSoundFontLibrary();
  },
);

// ---------------------------------------------------------------------------
// Midy playback events（MIDIモード）
// ---------------------------------------------------------------------------

function startGameMidi() {
  // リプレイ・2 回目以降の start では既存 Worker / OffscreenCanvas を再利用。
  // 毎回 initWorker() すると Canvas×3 の GPU バッファ破棄・再確保が走り、
  // メモリ/GPU のピークが跳ねやすい。
  ensureWorker();
  // 同一譜面なら thinNotes / structured clone はスキップされる。
  applyNotes();
  beginPlayback();
}

midy.addEventListener("started", startGameMidi);

midy.addEventListener("paused", () => {
  if (mode !== "midi") return;
  const fromUser = userInitiatedMidiPause;
  userInitiatedMidiPause = false;

  if (performance.now() < resumeGuardUntil) return;

  // ユーザー操作の一時停止。UI は togglePause 側で既に paused 済みのことが多い。
  // ここでは tick の同期のみ（大きな時刻を送って ended にしないよう isPaused 中は worker ended を無視）。
  if (fromUser) {
    stopRaf();
    if (gamePhase === "playing") {
      if (!isPaused) {
        try {
          _pausedAt = currentGameTime();
        } catch {
          /* ignore */
        }
        updatePauseUi(true);
      }
      try {
        worker?.postMessage({ type: "tick", currentTime: _pausedAt });
      } catch (err) {
        console.error("tick on pause failed:", err);
      }
    }
    return;
  }

  if (gamePhase === "result") {
    midy.seekTo(0);
    midy.setMasterVolume(1, audioContext.currentTime);
  }
});

midy.addEventListener("resumed", () => {
  if (mode !== "midi") return;
  // 再生開始時は必ず非一時停止 UI に揃える
  isPaused = false;
  pauseOverlay.classList.add("hidden");
  if (btnPause) {
    btnPause.classList.remove("hidden");
    btnPause.innerHTML = ICON_PAUSE;
  }
  // resume なので scoreDisplay の文字はリセットしない（現在のスコアを保持したまま出す）
  scoreDisplay?.classList.remove("hidden");
  if (gamePhase === "playing") {
    _resumeBaseGameTime = _pausedAt;
    _resumeBasePerf = performance.now();
    _resumeStabilizeMinUntil = _resumeBasePerf + RESUME_STABILIZE_MIN_MS;
    _resumeStabilizeMaxUntil = _resumeBasePerf + RESUME_STABILIZE_MAX_MS;
    startRaf();
    return;
  }
  startGameMidi();
});

midy.addEventListener("stopped", () => {
  if (mode !== "midi") return;
  // ユーザー一時停止中の誤 stopped ではスコア画面に行かない
  if (isPaused || userInitiatedMidiPause) return;
  // プレイ中の自然終了:
  // - すでにフェード中なら setTimeout / completeShortEnding に完了を任せる
  // - 未フェードなら Worker に finalize 付き stop を送り、judgmentDetail→ended
  //   経由で showResult する（未確定ホールドを確定してからスコアを確定する）
  if (gamePhase === "playing") {
    if (endingFadeStarted) {
      return;
    }
    stopRaf();
    let t = 0;
    try {
      t = currentGameTime();
    } catch {
      /* ignore */
    }
    try {
      worker?.postMessage({ type: "stop", currentTime: t, finalize: true });
    } catch (err) {
      console.error("worker stop failed:", err);
      showResult();
      systemPauseMidi();
    }
    // ended メッセージ側で showResult + systemPauseMidi する
  } else {
    stopRaf();
    try {
      worker?.postMessage({ type: "stop", finalize: false });
    } catch {
      /* ignore */
    }
  }
});

midy.addEventListener("seeked", () => {
  if (mode !== "midi" || gamePhase !== "playing") return;
  worker.postMessage({ type: "start" });
  lastResult = emptyResult(laneNotes.length);
  worker.postMessage({
    type: "tick",
    currentTime: midy.resumeTime - START_DELAY,
  });
});

midy.addEventListener("looped", () => {
  if (mode !== "midi") return;
  worker.postMessage({ type: "start" });
  lastResult = emptyResult(laneNotes.length);
});

midy.addEventListener("tempoChanged", () => {
  if (mode !== "midi") return;
  rawNotes = extractNotesFromMidy(midy);
  if (gamePhase !== "playing") {
    applyNotes();
    updatePlayLengthLabels();
  }
});

midy.addEventListener("started", () => midiLibrary.setPlayState("playing"));
midy.addEventListener("resumed", () => midiLibrary.setPlayState("playing"));
midy.addEventListener("paused", () => midiLibrary.setPlayState("paused"));
midy.addEventListener("stopped", () => midiLibrary.setPlayState("stopped"));

// ---------------------------------------------------------------------------
// 音声モード：譜面自動生成（beatmap-worker.js 経由）
// ---------------------------------------------------------------------------

let audioBuffer = null; // decodeAudioData 済みのバッファ（解析用）

function setAnalyzeUI(stage, progress) {
  document.getElementById("analyzingProgressBar").style.width = `${
    Math.round(progress * 100)
  }%`;
  document.getElementById("analyzingStage").textContent = stageLabel(stage);
}
function stageLabel(stage) {
  const known = new Set(["stft", "onset", "tempo", "grid", "notes", "done"]);
  return t(known.has(stage) ? `stage-${stage}` : "stage-default");
}

function audioBufferToMonoLocal(ab) {
  const ch = ab.numberOfChannels;
  if (ch === 1) return ab.getChannelData(0).slice();
  const len = ab.length;
  const out = new Float32Array(len);
  for (let c = 0; c < ch; c++) {
    const data = ab.getChannelData(c);
    for (let i = 0; i < len; i++) out[i] += data[i] / ch;
  }
  return out;
}

function analyze() {
  return new Promise((resolve, reject) => {
    if (!audioBuffer || !beatWorker) {
      reject(new Error(t("audioNotLoaded")));
      return;
    }

    let settled = false;
    const timeoutId = setTimeout(() => {
      if (settled) return;
      settled = true;
      pendingAnalysisResolve = pendingAnalysisReject = null;
      reject(
        new Error(t("analyzeTimeout", { seconds: ANALYZE_TIMEOUT_MS / 1000 })),
      );
    }, ANALYZE_TIMEOUT_MS);

    pendingAnalysisResolve = (msg) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      resolve(msg);
    };
    pendingAnalysisReject = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeoutId);
      reject(err);
    };

    setAnalyzeUI("stft", 0.02);
    const mono = audioBufferToMonoLocal(audioBuffer);
    beatWorker.postMessage(
      {
        type: "analyze",
        samples: mono,
        sampleRate: audioBuffer.sampleRate,
        difficulty: config.difficulty,
      },
      [mono.buffer],
    );
  });
}

function initBeatWorker() {
  if (beatWorker) beatWorker.terminate();
  beatWorker = new Worker("/flip-flap-notes/beatmap-worker.js", {
    type: "module",
  });
  beatWorker.onmessage = (e) => {
    const msg = e.data;
    if (msg.type === "progress") {
      setAnalyzeUI(msg.stage, msg.progress);
    } else if (msg.type === "result") {
      if (msg.notes.length === 0) {
        pendingAnalysisReject?.(new Error(t("noOnsetDetected")));
        pendingAnalysisResolve = pendingAnalysisReject = null;
        return;
      }
      rawNotes = msg.notes;
      applyNotes();
      notesReady = true;
      notesStale = false;
      pendingAnalysisResolve?.(msg);
      pendingAnalysisResolve = pendingAnalysisReject = null;
    } else if (msg.type === "error") {
      pendingAnalysisReject?.(new Error(msg.message));
      pendingAnalysisResolve = pendingAnalysisReject = null;
    }
  };
  beatWorker.onerror = (err) => {
    console.error("beatmap-worker crashed:", err);
    const message = err?.message
      ? t("analyzeWorkerErrorPrefix") + err.message
      : t("analyzeWorkerErrorUnknown");
    pendingAnalysisReject?.(new Error(message));
    pendingAnalysisResolve = pendingAnalysisReject = null;
  };
}

async function loadAudioFile(file) {
  if (!file) return;
  switchMode("audio");
  const buf = await file.arrayBuffer();
  const ctx = new (globalThis.AudioContext || globalThis.webkitAudioContext)();
  audioBuffer = await ctx.decodeAudioData(buf.slice(0));
  player.src = URL.createObjectURL(file);
  player.load();
  notesReady = false;
  notesStale = true;
  rawNotes = [];
  // ローカル音声にはライブラリ由来の著作権情報がない
  clearTrackMeta();
  buildGame();
  updatePlayLengthLabels();
  showScreen("ready");
}

/** 音声モードの1プレイ開始。START_DELAY 秒のリードイン後に <audio> を再生する。 */
function beginAudioRound() {
  clearAudioLeadIn();
  // 自前の pause を user-pause と誤認しない
  if (!player.paused) {
    suppressPauseHandling = true;
    player.pause();
  }
  player.currentTime = 0;
  player.volume = 1;
  _audioLeadIn = true;
  _audioLeadInStartPerf = performance.now();
  if (gamePhase === "playing") {
    // リプレイ: 既に playing のままリセット
    endingFadeStarted = false;
    endingFadeStartPerf = 0;
    if (endingFadeTimeoutId !== null) {
      clearTimeout(endingFadeTimeoutId);
      endingFadeTimeoutId = null;
    }
    lastResult = emptyResult(laneNotes.length);
    worker?.postMessage({ type: "start" });
    isPaused = false;
    showPlayHud();
    startRaf();
    uiCanvas.focus({ preventScroll: true });
  } else {
    beginPlayback();
  }
  scheduleAudioLeadInEnd(START_DELAY);
}

async function analyzeThenPlay() {
  isAnalyzing = true;
  try {
    buildGame();
    showScreen("analyzing");
    await analyze();
    isAnalyzing = false; // ここで解除してから開始しないと自分自身のガードで弾かれる
    beginAudioRound();
  } catch (err) {
    isAnalyzing = false;
    console.error(err);
    alert(t("beatmapGenerationFailedPrefix") + err.message);
    showScreen("ready");
  }
}

player.addEventListener("play", () => {
  if (mode !== "audio") return;
  if (!audioBuffer) {
    player.pause();
    return;
  }
  if (isAnalyzing) {
    player.pause();
    return;
  }

  if (notesStale || !notesReady) {
    suppressPauseHandling = true;
    player.pause();
    analyzeThenPlay();
    return;
  }

  if (gamePhase === "playing") {
    // リードイン完了による play、または一時停止からの再開
    if (_audioLeadIn) _audioLeadIn = false;
    updatePauseUi(false);
    startRaf();
    uiCanvas.focus({ preventScroll: true });
  } else {
    beginPlayback();
  }
});

player.addEventListener("pause", () => {
  if (mode !== "audio") return;
  if (suppressPauseHandling) {
    suppressPauseHandling = false;
    return;
  }
  if (performance.now() < resumeGuardUntil) return;
  if (gamePhase === "playing") {
    stopRaf();
    updatePauseUi(true);
  }
});

player.addEventListener("ended", () => {
  if (mode !== "audio") return;
  if (gamePhase === "playing") {
    stopRaf();
    // 未確定ホールドを確定してから judgmentDetail → ended → showResult
    let t = 0;
    try {
      t = currentGameTime();
    } catch {
      /* ignore */
    }
    try {
      worker?.postMessage({ type: "stop", currentTime: t, finalize: true });
    } catch (err) {
      console.error("worker stop failed:", err);
      showResult();
    }
  }
});

// 準備完了画面中央の「スタート」ボタン、およびリザルト画面の「もう一度プレイ」ボタン。
// 音声モードは beginAudioRound()（START_DELAY リードイン後に play）。
// MIDIモードは startMidiPlayback()（split soundfont の読み込み → midy.start()）。

// 連打で startMidiPlayback / analyzeThenPlay が並行起動しないようにする。
// 成功時は gamePhase が "playing" に遷移するので再入は弾かれるが、
// await 中はまだ ready/result のままなのでフラグが必要。
let startOrReplayBusy = false;

async function startOrReplay() {
  if (startOrReplayBusy) return;
  if (gamePhase !== "ready" && gamePhase !== "result") return;
  startOrReplayBusy = true;
  const startBtn = document.getElementById("btnBigStart");
  const replayBtn = document.getElementById("btnBigReplay");
  if (startBtn) startBtn.disabled = true;
  if (replayBtn) replayBtn.disabled = true;
  try {
    try {
      if (audioContext.state !== "running") await audioContext.resume();
    } catch (err) {
      console.error("audioContext.resume failed:", err);
    }
    if (mode === "audio") {
      if (notesStale || !notesReady) {
        await analyzeThenPlay();
      } else {
        beginAudioRound();
      }
    } else if (mode === "midi") {
      try {
        await startMidiPlayback();
      } catch (err) {
        console.error("startMidiPlayback failed:", err);
      }
    }
  } finally {
    startOrReplayBusy = false;
    // 遷移後は画面ごと隠れるので、戻ってきたときに押せるよう常に解除する
    if (startBtn) startBtn.disabled = false;
    if (replayBtn) replayBtn.disabled = false;
  }
}

document.getElementById("btnBigStart").addEventListener("click", startOrReplay);
document.getElementById("btnBigReplay").addEventListener(
  "click",
  startOrReplay,
);

// ---------------------------------------------------------------------------
// Background（MIDI/音声共通）
// ---------------------------------------------------------------------------

const backgroundImage = document.getElementById("backgroundImage");
const backgroundVideo = document.getElementById("backgroundVideo");
const VIDEO_EXTS = new Set(["mp4", "webm", "ogv", "ogg", "mov"]);

function hideBackground() {
  backgroundImage.hidden = true;
  backgroundVideo.hidden = true;
  backgroundVideo.pause();
  backgroundVideo.removeAttribute("src");
  backgroundImage.removeAttribute("src");
}
function showImageBackground(src) {
  backgroundVideo.hidden = true;
  backgroundVideo.removeAttribute("src");
  backgroundImage.src = src;
  backgroundImage.hidden = false;
}
function showVideoBackground(src) {
  backgroundImage.hidden = true;
  backgroundImage.removeAttribute("src");
  backgroundVideo.src = src;
  backgroundVideo.hidden = false;
  backgroundVideo.play().catch((err) =>
    console.warn(
      "Background video playback failed (likely autoplay policy):",
      err,
    )
  );
}
function loadBackgroundUrl(url) {
  VIDEO_EXTS.has(url.split(".").pop().toLowerCase())
    ? showVideoBackground(url)
    : showImageBackground(url);
}

// カスタム背景ファイルの永続化（IndexedDB）。
// URL.createObjectURL() の Blob URL はページを閉じると無効になるため、
// リロード後も同じ背景を復元できるよう、ファイル本体を IndexedDB に保存しておく。
// プリセット背景（./data/... のURL）は文字列なので config 経由で localStorage に保存すればよい。
const BG_DB_NAME = "FlipFlapNotesBackground";
const BG_STORE = "files";
function openBackgroundDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(BG_DB_NAME, 1);
    req.onupgradeneeded = () => {
      req.result.createObjectStore(BG_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function saveBackgroundFile(blob) {
  const db = await openBackgroundDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(BG_STORE, "readwrite");
    tx.objectStore(BG_STORE).put(blob, "custom");
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
async function loadBackgroundFile() {
  const db = await openBackgroundDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(BG_STORE, "readonly");
    const req = tx.objectStore(BG_STORE).get("custom");
    req.onsuccess = () => resolve(req.result ?? null);
    req.onerror = () => reject(req.error);
  });
}
async function clearBackgroundFile() {
  const db = await openBackgroundDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(BG_STORE, "readwrite");
    tx.objectStore(BG_STORE).delete("custom");
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// 設定モーダル中の背景変更はプレビューのみ。適用ボタンで初めて永続化し、
// キャンセル（hide.bs.modal + configSnapshot あり）では表示も config も元に戻す。
// pendingBackground: null = 未変更 / { preset: string, file?: File }
// （preset は "" | "custom" | プリセットURL）
let pendingBackground = null;
let pendingBackgroundObjectUrl = null;

function revokePendingBackgroundObjectUrl() {
  if (pendingBackgroundObjectUrl) {
    URL.revokeObjectURL(pendingBackgroundObjectUrl);
    pendingBackgroundObjectUrl = null;
  }
}

function setBackgroundSelectValue(preset) {
  const presetEl = document.getElementById("backgroundPreset");
  if (presetEl) presetEl.value = preset || "";
}

/** 表示だけ更新する（config / IndexedDB は触らない） */
function previewBackground(preset, file = null) {
  setBackgroundSelectValue(preset);
  revokePendingBackgroundObjectUrl();
  if (!preset) {
    hideBackground();
    return;
  }
  if (preset === "custom") {
    if (file) {
      pendingBackgroundObjectUrl = URL.createObjectURL(file);
      file.type.startsWith("video/")
        ? showVideoBackground(pendingBackgroundObjectUrl)
        : showImageBackground(pendingBackgroundObjectUrl);
    } else {
      // 保存済みカスタムを表示（キャンセルで元の custom に戻すとき等）
      loadBackgroundFile()
        .then((blob) => {
          if (!blob) {
            hideBackground();
            return;
          }
          pendingBackgroundObjectUrl = URL.createObjectURL(blob);
          blob.type.startsWith("video/")
            ? showVideoBackground(pendingBackgroundObjectUrl)
            : showImageBackground(pendingBackgroundObjectUrl);
        })
        .catch((err) => {
          console.error("背景ファイルの復元に失敗:", err);
          hideBackground();
        });
    }
    return;
  }
  loadBackgroundUrl(preset);
}

/** 適用時: pending を config + IndexedDB に書き込む */
function commitPendingBackground() {
  if (!pendingBackground) return;
  const { preset, file } = pendingBackground;
  config.backgroundPreset = preset;
  if (preset === "custom" && file) {
    saveBackgroundFile(file).catch((err) =>
      console.error("背景ファイルの保存に失敗:", err)
    );
  } else if (!preset) {
    clearBackgroundFile().catch((err) =>
      console.error("背景ファイルの削除に失敗:", err)
    );
  }
  // プリセットURLへ切り替えた場合は IndexedDB の custom をクリアして容量を戻す
  if (preset && preset !== "custom") {
    clearBackgroundFile().catch((err) =>
      console.error("背景ファイルの削除に失敗:", err)
    );
  }
  pendingBackground = null;
  // object URL は表示中に使っているので revoke しない（ページ離脱時に破棄される）
  pendingBackgroundObjectUrl = null;
}

/** キャンセル時: スナップショットの preset 表示へ戻し、pending を破棄 */
function revertPendingBackground(snapshotPreset) {
  pendingBackground = null;
  // file input も空にして、次回同じファイルを選べるようにする
  const fileEl = document.getElementById("backgroundFile");
  if (fileEl) fileEl.value = "";
  previewBackground(snapshotPreset ?? "");
}

document.getElementById("backgroundPreset")?.addEventListener("change", (e) => {
  const v = e.currentTarget.value;
  if (v === "custom") {
    // ファイル選択ダイアログへ。確定は backgroundFile の change、
    // ダイアログキャンセル時は select を pending / config の値に戻す。
    document.getElementById("backgroundFile").click();
    // ダイアログをキャンセルすると change が来ないため、select が "custom" のまま
    // 残るのを防ぐ。既に pending で custom を選んでいればそのまま、
    // そうでなければ直前の確定値（または pending の preset）に戻す。
    const fallback = pendingBackground?.preset ?? config.backgroundPreset ?? "";
    if (fallback !== "custom") {
      // ファイル選択の結果を待ってから、選ばれなかった場合だけ戻す。
      // （change が発火すれば pending が custom になる。発火しなければ戻す）
      const onFocusBack = () => {
        globalThis.removeEventListener("focus", onFocusBack);
        setTimeout(() => {
          if (pendingBackground?.preset !== "custom") {
            setBackgroundSelectValue(
              pendingBackground?.preset ?? config.backgroundPreset ?? "",
            );
          }
        }, 300);
      };
      globalThis.addEventListener("focus", onFocusBack);
    }
    return;
  }
  pendingBackground = { preset: v };
  previewBackground(v);
});
document.getElementById("backgroundFile")?.addEventListener(
  "change",
  (e) => {
    const f = e.target.files[0];
    if (!f) {
      // ファイル未選択（キャンセル相当）→ select を元に戻す
      setBackgroundSelectValue(
        pendingBackground?.preset ?? config.backgroundPreset ?? "",
      );
      return;
    }
    pendingBackground = { preset: "custom", file: f };
    previewBackground("custom", f);
  },
);

// ページ読み込み時、保存されている背景設定を復元してスタート画面にも反映する
async function restoreBackground() {
  const v = config.backgroundPreset;
  if (!v) {
    setBackgroundSelectValue("");
    return;
  }
  if (v === "custom") {
    try {
      const blob = await loadBackgroundFile();
      if (blob) {
        const url = URL.createObjectURL(blob);
        blob.type.startsWith("video/")
          ? showVideoBackground(url)
          : showImageBackground(url);
        setBackgroundSelectValue("custom");
      }
    } catch (err) {
      console.error("背景ファイルの復元に失敗:", err);
    }
  } else {
    loadBackgroundUrl(v);
    setBackgroundSelectValue(v);
  }
}

// ---------------------------------------------------------------------------
// タブ / ブラウザ背面・前面
// ---------------------------------------------------------------------------
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    pauseForBackground();
    return;
  }
  kickAudioContextSync();
  if (gamePhase === "playing" && !isPaused) {
    gameLogicTick();
  }
});
globalThis.addEventListener("pagehide", () => {
  pauseForBackground();
});
globalThis.addEventListener("pageshow", () => {
  kickAudioContextSync();
});
audioContext.addEventListener("statechange", () => {
  if (performance.now() < resumeGuardUntil) return;
  if (isPaused || gamePhase !== "playing") return;
  if (
    audioContext.state === "suspended" ||
    audioContext.state === "interrupted"
  ) {
    kickAudioContextSync();
  }
});

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

initBeatWorker();
buildGame();
showScreen("start");
restoreBackground();
setTimeout(setWrapHeight, 80);

installIOSTouchGuards({
  surfaceSelector: "#canvasWrap, #uiCanvas, canvas",
  uiSelector: [
    "#topnav",
    ".navbar-brand",
    "#btnPause",
    "#pauseOverlay",
    "#screenStart",
    "#screenReady",
    "#screenAnalyzing",
    "#screenResult",
    ".overlay",
    ".modal",
    ".modal-backdrop",
    "button",
    "a",
    "input",
    "select",
    "textarea",
    "label",
  ].join(", "),
  shouldBlockSurface: () => gamePhase === "playing",
  styleElementId: "iosTouchGuardsStyle",
});
